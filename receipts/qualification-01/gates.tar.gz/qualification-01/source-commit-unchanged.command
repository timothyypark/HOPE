cmp /workspace/.cloud-setup/v2-simulation-verification/qualification-01/code-sha.txt /workspace/.cloud-setup/v2-simulation-verification/qualification-01/final-code-sha.txt 
