ctest --test-dir /workspace/.cloud-setup/v2-simulation-verification/qualification-01/native --output-on-failure 
