test \! -s /workspace/.cloud-setup/v2-simulation-verification/qualification-01/final-worktree-status.txt 
