from pathlib import Path
import csv,json
root=Path('/workspace/.cloud-setup/v2-simulation-verification');q=root/'qualification-01'
assert (q/'aggregate.exit').exists()
def stages(path):
 with path.open() as f:
  metadata=f.readline();assert 'overwritten=0' in metadata
  return list(csv.DictReader(f,delimiter='\t'))
results=[]
for trial in map(json.loads,(q/'incoming-campaign/outcomes.jsonl').read_text().splitlines()):
 if trial['status']=='PASS':continue
 folder=q/'incoming-campaign'/f"repetition-{trial['repetition']}"/trial['profile']
 raw=json.loads((folder/'raw.json').read_text());trace=stages(folder/'planner.tsv')
 relay=[json.loads(s) for s in (folder/'relay.tsv').read_text().splitlines()]
 assert relay[0]['overwritten']==0
 received={int(r['source_ns']):r for r in trace if r['stage']=='planner_received'}
 source={r['source_ns']:r for r in raw['source']['rows']}
 rejected=[]
 for row in trace:
  if row['stage']!='command_rejected':continue
  packet=next(p for p in raw['received']['packets'] if p['cutoff_ns']==int(row['source_ns']))
  samples=[]
  for stamp in packet['sample_sources']:
   receipt=received.get(stamp)
   samples.append(dict(source_ns=stamp,source=source.get(stamp),
      planner_receipt_age_ms=(int(receipt['wall_ns'])-stamp)*1e-6 if receipt else None,
      planner_stages=[r for r in trace if int(r['source_ns'])==stamp],
      relay_stages=[r for r in relay[1:] if r[1]==stamp]))
  rejected.append(dict(rejection=row,packet=packet,samples=samples))
 late=[]
 for row in trace:
  if row['stage'] not in {'forecast_published','command_published'} or int(row['source_ns'])<=0:continue
  age=(int(row['wall_ns'])-int(row['source_ns']))*1e-6
  if age<=30:continue
  stamp=int(row['source_ns'])
  late.append(dict(stage=row,completion_age_ms=age,
                   predictions=[r for r in raw['received']['predictions'] if r['source_ns']==stamp],
                   candidates=[r for r in raw['received']['candidates'] if r['source_ns']==stamp],
                   revocations=[r for r in raw['received']['revocations'] if r['source_ns']==stamp]))
 results.append(dict(profile=trial['profile'],repetition=trial['repetition'],raw_gates=trial['result']['gates'],rejected_packets=rejected,late_publications=late))
(root/'current-incoming-failure-analysis.json').write_text(json.dumps(results,indent=2)+'\n')
for row in results:
 print(row['profile'],row['repetition'],'late publications',len(row['late_publications']))
 for packet in row['rejected_packets']:
  print('packet',packet['packet']['sequence'],packet['rejection']['reason'])
  for sample in packet['samples']:
   if sample['planner_receipt_age_ms'] is None or sample['planner_receipt_age_ms']>30:
    print('missing/expired sample',sample['source_ns'],sample['planner_receipt_age_ms'])
