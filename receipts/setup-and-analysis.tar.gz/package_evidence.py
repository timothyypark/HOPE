"""Package receipts only after all timed trials finish; never delete originals."""
from pathlib import Path
import gzip, hashlib, json, shutil, tarfile

root = Path('/workspace/.cloud-setup/v2-simulation-verification')
out = Path('/workspace/HOPE-v2-simulation-evidence')
assert (root / 'qualification-01/aggregate.exit').exists()
assert (root / 'lifecycle-instrumentation-comparison/summary.json').exists()
assert not (out / 'inventory.jsonl').exists(), 'Evidence package already created'
suffixes = {'.json', '.jsonl', '.xml', '.txt', '.log', '.exit', '.command', '.tsv',
            '.csv', '.stages', '.input', '.stderr', '.png', '.yaml', '.yml', '.py',
            '.sh', '.cpp', '.hpp', '.md'}

def selected(path):
    rel = path.relative_to(root)
    if path.is_symlink() or not path.is_file():
        return False
    if any(part in {'python-deps', '__pycache__', 'install', 'CMakeFiles', '.git'}
           for part in rel.parts):
        return False
    # Frozen baseline source trees are identified by commit; retain their receipts.
    if 'source' in rel.parts and ('premerge-v2' in rel.parts or 'failing-before' in rel.parts):
        return False
    if 'qualification-01-sanitizer-retention' in rel.parts:
        return path.name == 'inventory.json'
    return path.suffix in suffixes or path.name in {'CTestTestfile.cmake', 'CMakeCache.txt'}

groups = {}
for path in sorted(root.rglob('*')):
    if not selected(path):
        continue
    rel = path.relative_to(root)
    if len(rel.parts) == 1:
        group = 'setup-and-analysis'
    elif rel.parts[0] == 'qualification-01':
        if len(rel.parts) > 4 and rel.parts[1] in {'repeated-campaign', 'incoming-campaign'}:
            group = '/'.join(rel.parts[:4])
        elif len(rel.parts) > 2:
            group = '/'.join(rel.parts[:2])
        else:
            group = 'qualification-01/gates'
    else:
        group = rel.parts[0]
    groups.setdefault(group, []).append(path)

inventory = []
archives = []
for group, paths in groups.items():
    archive = out / 'receipts' / (group + '.tar.gz')
    archive.parent.mkdir(parents=True, exist_ok=True)
    with archive.open('wb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as tar:
                for path in paths:
                    rel = path.relative_to(root)
                    digest = hashlib.sha256(path.read_bytes()).hexdigest()
                    tar.add(path, arcname=str(rel), recursive=False)
                    inventory.append(dict(path=str(rel), bytes=path.stat().st_size,
                                          sha256=digest, archive=str(archive.relative_to(out))))
    # Independently decompress every member and verify its retained bytes.
    expected = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in paths}
    with tarfile.open(archive, 'r:gz') as tar:
        actual = {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest()
                  for m in tar.getmembers() if m.isfile()}
    assert actual == expected
    archives.append(dict(path=str(archive.relative_to(out)), files=len(paths),
                         bytes=archive.stat().st_size,
                         sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
    print(group, len(paths), archive.stat().st_size, flush=True)

(out / 'inventory.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in inventory))
(out / 'archives.json').write_text(json.dumps(archives, indent=2) + '\n')
(out / 'reports').mkdir(exist_ok=True)
for path in root.glob('*.json'):
    if path.name != 'pr-before.json':
        shutil.copy2(path, out / 'reports' / path.name)
for folder in ['incoming-conversion', 'mujoco-conversion']:
    for name in ['result.json', 'summary.json', 'manifest.json']:
        path = root / 'qualification-01' / folder / name
        if path.exists():
            shutil.copy2(path, out / 'reports' / (folder + '-' + name))
(out / 'plots').mkdir(exist_ok=True)
for folder in ['forecast-path-review', 'conversion-02']:
    for path in (root / folder).glob('*.png'):
        shutil.copy2(path, out / 'plots' / path.name)
print('Verified', len(inventory), 'files in', len(archives), 'archives')
