#include "hope_planner_cpp/incoming_trajectory.hpp"
#include <iostream>
#include <iomanip>
#include <map>
namespace rclcpp {
struct Node {
 std::map<std::string,double> parameters;
 template<class T> T declare_parameter(const std::string& key,T fallback) {
  auto it=parameters.find(key);return it==parameters.end()?fallback:static_cast<T>(it->second);
 }
};
}
namespace hope_planner_cpp {
inline FutureContactConfig declare_future_contact_config(rclcpp::Node& node) {
  FutureContactConfig c;
  c.spin_enabled = node.declare_parameter<bool>("future_contact_spin_enabled", false);
  c.magnus_enabled = node.declare_parameter<bool>("future_contact_magnus_enabled", false);
  c.tangential_gain = node.declare_parameter<double>("future_contact_spin_tangential_gain", c.tangential_gain);
  c.omega_scale = node.declare_parameter<double>("future_contact_spin_omega_scale", c.omega_scale);
  c.min_coherence = node.declare_parameter<double>("future_contact_spin_min_coherence", c.min_coherence);
  return c;
}

inline SpinEstimatorConfig declare_spin_estimator_config(rclcpp::Node& node) {
  SpinEstimatorConfig c;
  c.window_s = node.declare_parameter<double>("spin_window_s", 0.10);
  c.min_span_s = node.declare_parameter<double>("spin_min_span_s", 0.05);
  c.max_gap_s = node.declare_parameter<double>("spin_max_gap_s", 0.05);
  c.max_rev_s = node.declare_parameter<double>("spin_max_rev_s", 20.0);
  c.huber_delta_rev_s = node.declare_parameter<double>("spin_huber_delta_rev_s", 2.0);
  c.min_increments = static_cast<std::size_t>(std::max(1, static_cast<int>(node.declare_parameter<int>("spin_min_increments", 3))));
  c.robust_iterations = std::max(1, static_cast<int>(node.declare_parameter<int>("spin_robust_iterations", 5)));
  return c;
}

IncomingTrajectoryConfig declare_trajectory_config(rclcpp::Node& node) {
  IncomingTrajectoryConfig config;
  config.net_x = node.declare_parameter<double>("net_x", 1.37);
  config.estimator_window_s =
      node.declare_parameter<double>("flight_window_s", 0.18);
  config.estimator_max_sample_gap_s =
      node.declare_parameter<double>("batch_max_sample_gap_s", 0.0);
  config.commit_delay_s =
      node.declare_parameter<double>("post_net_commit_delay_s", 0.05);
  config.adaptive.enabled = node.declare_parameter<bool>("adaptive_commit_enabled", false);
  config.adaptive.policy_lead_s = node.declare_parameter<double>("adaptive_policy_lead_s", 0.35);
  config.adaptive.transport_budget_s = node.declare_parameter<double>("adaptive_transport_budget_s", 0.10);
  config.adaptive.solve_budget_s = node.declare_parameter<double>("adaptive_solve_budget_s", 0.005);
  config.adaptive.policy_tick_s = node.declare_parameter<double>("adaptive_policy_tick_s", 0.02);
  config.adaptive.max_sample_age_s = node.declare_parameter<double>("adaptive_max_sample_age_s", 0.05);
  config.adaptive.evaluation_period_s = node.declare_parameter<double>("adaptive_evaluation_period_s", 0.01);
  config.opponent_side_margin_m =
      node.declare_parameter<double>("incoming_opponent_side_margin_m", 0.05);
  config.incoming_speed_threshold_mps =
      node.declare_parameter<double>("incoming_speed_threshold_mps", 0.25);
  config.outgoing_speed_threshold_mps =
      node.declare_parameter<double>("outgoing_speed_threshold_mps", 0.25);
  config.source_gap_reset_s =
      node.declare_parameter<double>("incoming_source_gap_reset_s", 0.25);
  config.direction_fit_samples = static_cast<std::size_t>(std::max(
      3, static_cast<int>(node.declare_parameter<int>(
             "incoming_direction_fit_samples", 4))));
  config.direction_confirmations = static_cast<std::size_t>(std::max(
      1, static_cast<int>(node.declare_parameter<int>(
             "incoming_direction_confirmations", 2))));
  config.pre_roll_samples = static_cast<std::size_t>(std::max(
      6, static_cast<int>(node.declare_parameter<int>(
             "incoming_pre_roll_samples", 24))));
  return config;
}

CommitPredictionConfig declare_prediction_config(rclcpp::Node& node) {
  CommitPredictionConfig config;
  config.future_contact = declare_future_contact_config(node);
  config.spin_estimator = declare_spin_estimator_config(node);
  config.observed_physics.drag_k = node.declare_parameter<double>("drag_k", BallPhysics{}.drag_k);
  config.observed_physics.magnus_k = node.declare_parameter<double>("magnus_k", BallPhysics{}.magnus_k);
  config.observed_physics.restitution_h = node.declare_parameter<double>("restitution_h", BallPhysics{}.restitution_h);
  config.observed_physics.restitution_v = node.declare_parameter<double>("restitution_v", BallPhysics{}.restitution_v);
  config.observed_physics.table_tangential_gain = node.declare_parameter<double>("table_tangential_gain", BallPhysics{}.table_tangential_gain);
  config.observed_physics.table_friction_cap_mu = node.declare_parameter<double>("table_friction_cap_mu", BallPhysics{}.table_friction_cap_mu);
  config.estimator.spin_enabled = config.future_contact.magnus_enabled;
  config.estimator.spin_min_coherence = config.future_contact.min_coherence;
  config.estimator.single_flight_only =
      node.declare_parameter<bool>("batch_single_flight_only", false);
  config.estimator.min_span_s =
      node.declare_parameter<double>("batch_estimator_min_span_s", 0.08);
  config.estimator.min_samples = static_cast<std::size_t>(std::max(
      6, static_cast<int>(node.declare_parameter<int>("batch_estimator_min_samples", 12))));
  config.estimator.huber_delta_m = node.declare_parameter<double>("batch_estimator_huber_delta_m", 0.003);
  config.estimator.recency_half_life_s =
      node.declare_parameter<double>("batch_estimator_recency_half_life_s", 0.0);
  config.estimator.robust_iterations = node.declare_parameter<int>("batch_estimator_iterations", 3);
  config.future_physics = config.observed_physics;
  config.future_physics.table_tangential_gain = node.declare_parameter<double>("post_net_future_bounce_tangential_gain", config.observed_physics.table_tangential_gain);
  config.future_physics.restitution_v = node.declare_parameter<double>("post_net_future_bounce_restitution_v", config.observed_physics.restitution_v);
  config.planner.x_hit = node.declare_parameter<double>("adaptive_scheduling_x_hit", 0.15);
  config.planner.adaptive_predict_horizon = true;
  config.estimator.post_bounce_min_span_s = node.declare_parameter<double>(
      "batch_post_bounce_min_span_s", 0.0);
  config.estimator.post_bounce_exclusion_s = node.declare_parameter<double>(
      "batch_post_bounce_exclusion_s", 0.008);
  return config;
}

}
using namespace hope_planner_cpp;
int main(){
 rclcpp::Node node;int parameters;std::cin>>parameters;
 for(int i=0;i<parameters;++i){std::string key;double value;std::cin>>key>>value;node.parameters[key]=value;}
 IncomingTrajectory trajectory(declare_trajectory_config(node),declare_prediction_config(node));
 trajectory.set_prediction_x_hit(.08);
 std::cout<<std::setprecision(17)<<"phase,source_ns,epoch,packet_count,first_ns,cutoff_ns,net_cross_s,commit_s\n";
 auto emit=[&](const IncomingTrajectoryUpdate& update,std::int64_t stamp){
  if(!update.snapshot_ready)return;
  const auto& s=update.snapshot;
  std::cout<<static_cast<int>(trajectory.phase())<<','<<stamp<<','<<s.trajectory_epoch<<','<<s.sample_count<<','
    <<s.samples[0].source_time_ns<<','<<s.latest_sample()->source_time_ns<<','
    <<s.one_shot.net_cross_source_time_s<<','<<s.one_shot.commit_source_time_s<<'\n';
 };
 BallSample sample;double angle;int orientation;std::int64_t timer=0;
 while(std::cin>>sample.source_time_ns>>sample.receipt_wall_ns>>sample.position.x()>>sample.position.y()>>sample.position.z()>>angle>>orientation){
  if(!timer)timer=sample.receipt_wall_ns;
  while(timer<sample.receipt_wall_ns){emit(trajectory.poll(timer*1e-9),timer);timer+=1000000;}
  sample.source_time_s=sample.source_time_ns*1e-9;
  sample.orientation_valid=true;
  sample.orientation=orientation?Eigen::Quaterniond(Eigen::AngleAxisd(angle,Vec3::UnitY())):Eigen::Quaterniond::Identity();
  emit(trajectory.observe(sample),sample.source_time_ns);
 }
 return std::cin.eof()?0:2;
}
