// Replay recorded decoder-arrival intervals into the real policy; no robot or HAL.
#include "a3_pingpong/pp_policy.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <thread>
int main(int argc,char** argv) {
 if(argc!=4)return 2;
 try {
  struct Event{double receipt;std::vector<double> wire;};
  std::ifstream stream(argv[3]);double original_origin,end;stream>>original_origin>>end;
  std::vector<Event> events;double receipt;size_t size;
  while(stream>>receipt>>size){Event e{receipt,{}};e.wire.resize(size);for(auto& v:e.wire)stream>>v;events.push_back(e);}
  if(events.empty())throw std::runtime_error("empty recorded input");
  a3_pingpong::PpPolicyConfig config;
  config.deploy_cfg_path=argv[2];config.shared_session_home=true;
  config.planner_preengagement_revocation=true;config.planner_mode=true;
  config.policy_native=true;config.single_swing=true;config.level=0;config.engage_settle_s=0;
  config.loc_mode=a3_pingpong::LocMode::kExternalBase;
  a3_pingpong::PpPolicy policy(argv[1],config);
  auto base=std::make_shared<a3_pingpong::PpBasePoseInput>();
  auto input=std::make_shared<a3_pingpong::PpRacketTargetInput>(4,true);
  policy.SetBasePoseInput(base);policy.SetRacketInput(input);
  robot_io::RobotState state;state.q=policy.official_stand_q();state.dq=Eigen::VectorXd::Zero(31);
  state.imu_quat_wxyz=Eigen::Vector4d(1,0,0,0);state.imu_gyro.setZero();
  std::uint64_t tick=0;
  auto step=[&]{
   auto stamp=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
   base->SetFromFlat({2,1,double(tick+1),double(stamp/1000000000LL),double(stamp%1000000000LL),-.5,-.7625,.95,1,0,0,0,1,47,7,8});
   robot_io::RobotCommand command;
   if(!policy.ComputeCommand(tick++,state,command))throw std::runtime_error("policy step failed");
  };
  for(int i=0;i<10;++i){step();std::this_thread::sleep_for(std::chrono::milliseconds(20));}
  auto home=policy.session_home_unsafe();if(!home.epoch)throw std::runtime_error("no HOME");
  double origin=a3_pingpong::PpNowWallSec()+.03,shift=origin-original_origin;
  std::size_t next=0;bool engaged=false;double first_engaged=-1;
  std::cout<<"elapsed_s,sequence,invalid_after,level,status\n";
  while(a3_pingpong::PpNowWallSec()<origin+end+.1){
   double elapsed=a3_pingpong::PpNowWallSec()-origin;
   while(next<events.size() && events[next].receipt<=elapsed){
    auto wire=events[next++].wire;
    if(wire[1])wire[10]+=shift;
    double stamp=wire[12]+wire[13]*1e-9+shift;wire[12]=std::floor(stamp);wire[13]=std::floor((stamp-std::floor(stamp))*1e9);
    wire[19]=double(home.epoch); // Fresh local identity; numeric HOME/target geometry unchanged.
    input->SetFromFlat(wire);
   }
   step();auto snapshot=input->Latest();auto trace=policy.planner_trace_snapshot(tick);
   if(policy.level()==1 && !engaged){engaged=true;first_engaged=elapsed;}
   std::cout<<elapsed<<','<<snapshot.seq<<','<<snapshot.invalid_after<<','<<policy.level()<<','<<trace.status<<'\n';
   std::this_thread::sleep_for(std::chrono::milliseconds(20));
  }
  std::cerr<<"RECORDED_REPLAY engaged="<<engaged<<" first_engaged_s="<<first_engaged<<" consumed="<<next<<" home="<<home.epoch<<'\n';
  return next==events.size()?0:3;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
