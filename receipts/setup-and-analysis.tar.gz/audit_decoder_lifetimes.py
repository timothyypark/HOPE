"""Report actual decoder retention/revocation without assuming policy engagement."""
from pathlib import Path
import csv,gzip,json,math
root=Path('/workspace/.cloud-setup/v2-simulation-verification')
assert (root/'qualification-01/aggregate.exit').exists(), 'Run after timed qualification'
def read(path):
 p=Path(path);p=p if p.exists() else p.with_name(p.name+'.gz')
 with gzip.open(p,'rt') if p.suffix=='.gz' else p.open() as f:return json.load(f)
reports=[read(root/'historical-audit-reproducible.json')['results'],[r['outcome'] for r in read(root/'campaign-outcome-assessment.json')['results']],[read(root/'full-ros-failure-outcome.json')]]
results=[]
for cases in reports:
 for case in cases:
  raw=read(case['raw_path']);incoming=case['profile'].startswith('incoming_')
  received=raw['received'] if incoming else raw
  wire=received['commands'] if incoming else received['wire'];decoded=received['decoded']
  commands={int(w[14]):w for w in wire if w[1]==1}
  sources={int(s.get('source_ns',s.get('stamp_ns'))):s for s in raw['source']['rows']}
  if incoming:
   p=Path(case['raw_path']).parent/'planner.tsv'
   p=p if p.exists() else p.with_name(p.name+'.gz')
   with gzip.open(p,'rt') if p.suffix=='.gz' else p.open() as f:
    f.readline();traces=[r for r in csv.DictReader(f,delimiter='\t') if r['stage']=='command_published']
  else:traces=raw['traces']
  identities={}
  for trace in traces:
   stamp=int(trace['source_ns'] if incoming else trace['source_time_ns'])
   seq=int(trace['sequence'] if incoming else trace['command_sequence'])
   if stamp not in sources or seq not in commands:continue
   src=sources[stamp]
   ordinal=src['flight'] if incoming else src['round'] if 'reacquisition' in case['profile'] else math.floor(src['state_elapsed_s']-.8)
   identities.setdefault(ordinal,set()).add(int(commands[seq][15]))
  all_ids=[identity for group in identities.values() for identity in group]
  assert len(all_ids)==len(set(all_ids)), 'Wire identity reused across physical flights'
  flights=[]
  for flight in case['flights']:
   first=flight['first_usable']
   if first is None:
    flights.append(dict(flight=flight['flight'],status='NO_USABLE_COMMAND'));continue
   command=commands[first['sequence']];identity=int(command[15]);arrival=command[10]
   flight_ids=identities[flight['flight']]
   all_rows=sorted(decoded,key=lambda d:d[13]*1e9+d[14])
   timeline=[d for d in all_rows if int(d[1]) in flight_ids]
   def state_at(epoch):
    eligible=[d for d in all_rows if d[13]+d[14]*1e-9<=epoch]
    if not eligible:return 'NO_DECODER_RECEIPT'
    if int(eligible[-1][1]) not in flight_ids:return 'OTHER_PHYSICAL_FLIGHT'
    return 'REVOKED_OR_INVALID_AFTER' if eligible[-1][10] else 'VALID_RETAINED'
   revocations=[dict(receipt_unix_s=d[13]+d[14]*1e-9,lead_s=arrival-d[13]-d[14]*1e-9,sequence=int(d[0])) for d in timeline if d[10] and d[13]+d[14]*1e-9<arrival]
   # Contiguous retention across harmless same-flight revisions; another flight
   # or an invalid-after receipt ends the interval. No policy engagement inferred.
   intervals=[];start=None
   for d in all_rows:
    epoch=d[13]+d[14]*1e-9
    valid=int(d[1]) in flight_ids and not d[10]
    if valid and start is None:start=epoch
    if not valid and start is not None:
     intervals.append((start,epoch));start=None
   if start is not None:intervals.append((start,arrival))
   spans=[max(0,min(end,arrival-.08)-begin) for begin,end in intervals]
   flights.append(dict(flight=flight['flight'],wire_flights=sorted(flight_ids),contact_unix_s=arrival,state_at_minimum_usable_lead=state_at(arrival-.08),state_at_contact=state_at(arrival),longest_valid_interval_before_minimum_lead_ms=1000*max(spans,default=0),revocations_before_contact=revocations,engagement='UNKNOWN; decoder is not the policy'))
  results.append(dict(profile=case['profile'],raw_path=case['raw_path'],flights=flights))
report=dict(scope='Supplementary actual-decoder lifetime evidence across all wire identities mapped to the same independent physical flight, including valid HOME-refresh replacement. No policy engagement or physical contact is inferred. Reference times use the first independently usable command and the already-declared 80 ms minimum lead. First-command-only diagnosis is retained separately.',results=results)
(root/'decoder-lifetime-assessment.json').write_text(json.dumps(report,indent=2)+'\n')
summary={}
for case in results:
 for flight in case['flights']:
  key=(flight.get('state_at_minimum_usable_lead',flight.get('status')),flight.get('state_at_contact'))
  summary[str(key)]=summary.get(str(key),0)+1
print(summary)
