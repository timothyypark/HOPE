from pathlib import Path
import gzip,hashlib,json
root=Path('/workspace/.cloud-setup/v2-simulation-verification');q=root/'qualification-01'
assert (q/'sanitized-test.exit').exists()
assert not (q/'ros-build.exit').exists()
out=root/'qualification-01-sanitizer-retention';out.mkdir(exist_ok=False);rows=[]
for p in sorted((q/'sanitized').rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 with p.open('rb') as f:magic=f.read(4)
 if magic!=b'\x7fELF' and p.suffix not in ['.a','.o']:continue
 data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();target=out/('__'.join(p.relative_to(root).parts)+'.gz')
 with gzip.open(target,'wb',compresslevel=3) as f:f.write(data)
 with gzip.open(target,'rb') as f:restored=f.read()
 assert hashlib.sha256(restored).hexdigest()==sha and len(restored)==len(data)
 rows.append(dict(original=str(p),retained=str(target),bytes=len(data),sha256=sha,compressed_bytes=target.stat().st_size))
 (out/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n');p.unlink()
print('Retained',len(rows),'sanitizer artifacts after test; saved',sum(r['bytes']-r['compressed_bytes'] for r in rows),'bytes')
