#!/usr/bin/env bash
set -eo pipefail
export GIT_CONFIG_COUNT=4
export GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/workspace/HOPE-v2-incoming
export GIT_CONFIG_KEY_1=safe.directory GIT_CONFIG_VALUE_1=/workspace/HOPE-pr85-bounded-ingress
export GIT_CONFIG_KEY_2=safe.directory GIT_CONFIG_VALUE_2=/workspace/HOPE-pr85-upstream-baseline
export GIT_CONFIG_KEY_3=safe.directory GIT_CONFIG_VALUE_3=/workspace/HOPE-integrated-reacquisition-spin
export HOPE_VERIFICATION_BUILD_JOBS=4
export HOPE_SIMULATION_PYTHONPATH=/workspace/.cloud-setup/v2-simulation-verification/python-deps
export XML_CATALOG_FILES=/workspace/.cloud-setup/ros-schema-catalog.xml
export HOPE_POLICY_PYTHONPATH=/workspace/.cloud-setup/reacquisition-spin/policy-python
export HOPE_SELECTED_UPSTREAM_BUILD=/workspace/.cloud-setup/pr85-integration/upstream/build
export HOPE_HOST_ENVIRONMENT_RECEIPT=/workspace/.cloud-setup/v2-incoming/qualification-06-host-environment.json
export HOPE_RUNNER_BASELINE_REPO=/workspace/HOPE-pr85-bounded-ingress
export ORT_ROOT=/workspace/.cloud-setup/v2-incoming/deps/onnxruntime-linux-x64-1.19.2
cd /workspace/HOPE-v2-incoming
export HOPE_VERIFICATION_SOURCE_ROOT=/workspace/HOPE-v2-incoming
bash /workspace/.cloud-setup/v2-simulation-verification/verify_integrated.sh /workspace/.cloud-setup/v2-simulation-verification/qualification-01
