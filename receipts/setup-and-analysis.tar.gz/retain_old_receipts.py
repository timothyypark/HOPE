import gzip,hashlib,json,os
from pathlib import Path
root=Path('/workspace/.cloud-setup/pr85-qualification')
manifest=Path('/workspace/.cloud-setup/v2-simulation-verification/storage-retention.jsonl')
with manifest.open('a') as log:
 for path in sorted(root.rglob('*')):
  if not path.is_file() or path.is_symlink() or path.stat().st_size<100000 or path.suffix not in ['.json','.csv','.tsv','.stages','.log']:continue
  dest=path.with_name(path.name+'.gz')
  if dest.exists():continue
  data=path.read_bytes();digest=hashlib.sha256(data).hexdigest()
  with gzip.open(dest,'wb',compresslevel=6) as f:f.write(data)
  with gzip.open(dest,'rb') as f:assert hashlib.sha256(f.read()).hexdigest()==digest
  log.write(json.dumps(dict(path=str(path),gzip=str(dest),sha256=digest,bytes=len(data),stored_bytes=dest.stat().st_size))+'\n');log.flush()
  path.unlink()
print('retained',sum(1 for _ in manifest.open()))
