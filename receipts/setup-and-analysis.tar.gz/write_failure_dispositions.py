from pathlib import Path
import gzip,json
root=Path('/workspace/.cloud-setup/v2-simulation-verification')
historical=json.loads((root/'historical-audit-reproducible.json').read_text())['results']
current=json.loads((root/'campaign-outcome-assessment.json').read_text())['results']
lifetimes={c['raw_path']:c for c in json.loads((root/'decoder-lifetime-assessment.json').read_text())['results']}
results=[]
for case in historical:
 useful=sum(f['usable_commands']>0 for f in case['flights'])
 if useful<case['expected_flights']:
  state='CONFIRMED_DEFECT';basis='Missing usable incoming command; packet/prefix/expiry causal receipts retained; no retry or freshness relaxation applied.'
 elif case['profile'].startswith('incoming_'):
  state='ACCEPTED_TIMING_DEVIATION';basis='User accepted historical 54.731069 ms publication; ten useful commands, unchanged expiry/invalidation.'
 else:
  state='VERIFIED_NO_FUNCTIONAL_IMPACT';basis='Skipped observation update did not remove the useful same-flight command; numerical conversion and corrected lifecycle gates pass; actual decoder retention checked.'
  if case['profile']=='base_yaw_chain_150_0':
   basis+=' First flight is deliberately revoked by wrong_frame inputs at source elapsed 1.0–1.08 s; its final invalid receipt is at elapsed 1.00242734 s. Second flight remains valid through contact. This is expected abstention after a source fault, not continuous first-flight retention.'
  else:assert all(f['state_at_contact']=='VALID_RETAINED' for f in lifetimes[case['raw_path']]['flights'])
 results.append(dict(origin='historical',profile=case['profile'],run=case['run'],raw_path=case['raw_path'],expected_flights=case['expected_flights'],useful_flights=useful,assessment=state,basis=basis))
for case in current:
 if case['raw_status']=='PASS':continue
 outcome=case['outcome'];useful=sum(f['usable_commands']>0 for f in outcome['flights'])
 if useful<outcome['expected_flights']:
  state='CONFIRMED_DEFECT';basis='Flight 9 packet has 44 exact samples. Three were typed-published within 0.661 ms but never recorded at planner receipt; exact-prefix rejection prevented a command. Missing command remains in denominator.'
 elif case['campaign']=='incoming-campaign':
  state='VERIFIED_NO_FUNCTIONAL_IMPACT';basis='New 41.784759 ms late forecast was ONE_SHOT_ALREADY_COMMITTED, command-ineligible, followed by explicit expiry. All ten commands decoded; actual recorded flight-8 command engaged before revocation in production-policy replay. Raw timing gate remains failed; no new expiry allowance.'
 else:
  state='VERIFIED_NO_FUNCTIONAL_IMPACT';basis='Every independently offered flight had a usable target. Four coverage failures retain targets through contact; the source-cadence failure is a startup gap before scored flights. Deliberate first-flight frame-fault withdrawal remains expected.'
 results.append(dict(origin='current_campaign',profile=case['profile'],run=case['repetition'],raw_path=outcome['raw_path'],raw_status=case['raw_status'],raw_exception=case['raw_exception'],expected_flights=outcome['expected_flights'],useful_flights=useful,assessment=state,basis=basis))
full=json.loads((root/'full-ros-failure-outcome.json').read_text())
results.append(dict(origin='current_full_ros',profile=full['profile'],run='full_ros',raw_path=full['raw_path'],raw_status='FAIL',assessment='VERIFIED_NO_FUNCTIONAL_IMPACT',expected_flights=2,useful_flights=2,basis='331.480 ms source startup gap before first flight at 0.8 s. Both scored flights had useful targets; intentional first-flight frame fault still revokes authority. Requested global source rate was not achieved.'))
report=dict(status='INCOMPLETE',scope='Per-failure dispositions under the declared software/simulation contract. Raw verdicts unchanged. Useful target receipt, retained decoder state and actual policy engagement are distinct evidence levels.',results=results,unresolved_lost_flight_cases=sum(r['assessment']=='CONFIRMED_DEFECT' for r in results),inherited_lint='bringup flake8/pep257 retain existing failures; zero added signatures')
(root/'failure-dispositions.json').write_text(json.dumps(report,indent=2)+'\n')
print(len(results),'cases;',report['unresolved_lost_flight_cases'],'unresolved lost-flight cases')
