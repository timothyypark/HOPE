from pathlib import Path
import json,sys
sys.path.insert(0,'/workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/scripts/flight_prediction_validation')
from coverage_outcome_audit import audit
root=Path('/workspace/.cloud-setup/v2-simulation-verification');q=root/'qualification-01';name='integrated_chain_150_ON_REFRESH'
p=q/'build/hope_planner_cpp'/(name+'.raw.json');raw=json.loads(p.read_text());result=audit(name,p)
rows=raw['source']['rows'];a,b=max(zip(rows,rows[1:]),key=lambda pair:pair[1]['stamp_ns']-pair[0]['stamp_ns'])
result['raw_exception']=raw['exception'];result['largest_source_gap']=dict(duration_ms=(b['stamp_ns']-a['stamp_ns'])/1e6,from_phase_s=a['state_elapsed_s'],to_phase_s=b['state_elapsed_s'],first_declared_flight_starts_s=.8)
(root/'full-ros-failure-outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(result['assessment'],[(r['flight'],r['usable_commands']) for r in result['flights']],result['largest_source_gap'])
