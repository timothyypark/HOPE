from pathlib import Path
import csv,gzip,json
root=Path('/workspace/.cloud-setup/v2-incoming/qualification-06/incoming-campaign')
out=Path('/workspace/.cloud-setup/v2-simulation-verification/packet-prefix-failures.json')
def stream(p):
 p=p if p.exists() else p.with_name(p.name+'.gz');return gzip.open(p,'rt') if p.suffix=='.gz' else p.open()
results=[]
for rep,profile in [(1,'300_per_ball_zero'),(3,'150_per_ball_unknown'),(4,'360_stable_per_ball_zero'),(4,'150_stable_per_ball_zero')]:
 folder=root/f'repetition-{rep}'/('incoming_chain_'+profile)
 raw=json.load(stream(folder/'raw.json'));source={r['source_ns']:r for r in raw['source']['rows']}
 with stream(folder/'planner.tsv') as f:
  metadata=f.readline();stages=list(csv.DictReader(f,delimiter='\t'))
 packets=list(csv.DictReader(stream(folder/'packetizer.csv')))
 for rejection in [r for r in stages if r['stage']=='command_rejected']:
  cutoff=int(rejection['source_ns']);packet=next(r for r in packets if int(r['last_exposure_unix_ns'])==cutoff)
  first=int(packet['first_exposure_unix_ns']);offered={s for s in source if first<=s<=cutoff and source[s]['present']}
  delivered={int(r['source_ns']):r for r in stages if r['stage']=='planner_received' and first<=int(r['source_ns'])<=cutoff}
  ages=[dict(source_ns=s,phase_s=source[s]['phase'],age_ms=(int(r['wall_ns'])-s)/1e6) for s,r in delivered.items()]
  result=dict(repetition=rep,profile=profile,flight=source[cutoff]['flight'],reason=rejection['reason'],first_source_ns=first,cutoff_ns=cutoff,packet_sample_count=int(packet['sample_count']),offered_in_packet_time_window=len(offered),typed_receipts_in_window=len(delivered),missing_typed_receipts=sorted(offered-set(delivered)),typed_receipt_age_over_30ms=[r for r in ages if r['age_ms']>30],packet_cutoff_to_rejection_ms=(int(rejection['wall_ns'])-cutoff)/1e6,packet_freeze_to_rejection_ms=(int(rejection['wall_ns'])-int(packet['freeze_wall_unix_ns']))/1e6,limitation='Historical packet receipts contain endpoints/count/hash but not the full interior source list. Do not infer exact missing packet frames; new producer-chain receipts retain sample_sources.')
  results.append(result)
out.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
