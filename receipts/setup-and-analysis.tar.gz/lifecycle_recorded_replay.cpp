#include "hope_planner_cpp/flight_state_v2.hpp"
#include <iostream>
using namespace hope_planner_cpp;
int main() {
 ShotSettings settings;settings.game_legality_advisory=true;settings.automatic_rearm=true;
 FlightPipeline pipeline({},settings);
 std::cout<<"source_ns,sequence,generation,state,reason,original_reason\n";
 char operation;BallSample sample;
 while(std::cin>>operation>>sample.source_time_ns>>sample.sequence) {
  if(operation=='R'){pipeline.shot().revoke_outputs("SOURCE_UNQUALIFIED");continue;}
  int orientation;double w,x,y,z;
  if(!(std::cin>>sample.position.x()>>sample.position.y()>>sample.position.z()>>w>>x>>y>>z>>orientation))return 2;
  sample.orientation_valid=sample.orientation_authoritative=orientation!=0;
  sample.orientation=orientation?Eigen::Quaterniond(w,x,y,z).normalized():Eigen::Quaterniond::Identity();
  sample.frame_id="world";sample.calibration_id="SYNTHETIC_MCT_P1";
  sample.clock_domain="ros_system";sample.clock_mapping_id="natnet_exposure_unix_v1";
  sample.clock_uncertainty_s=.00002;sample.ball_id="Ball";
  pipeline.observe(sample);
  std::cout<<sample.source_time_ns<<','<<sample.sequence<<','<<pipeline.shot().generation()<<','
    <<name(pipeline.shot().state())<<','<<(pipeline.shot().active()?pipeline.shot().reason():pipeline.shot().rejection_reason())<<','<<pipeline.shot().reason()<<'\n';
 }
 return std::cin.eof()?0:2;
}
