from pathlib import Path
import csv,json
root=Path('/workspace/.cloud-setup/v2-simulation-verification');r=root/'runner-recorded-replay'
m=json.loads((r/'manifest.json').read_text());out=[]
for trial in m['trials']:
 rows=list(csv.DictReader((r/(trial['name']+'.csv')).open()))
 first=min(float(x['elapsed_s']) for x in rows if x['level']=='1')
 events=[line.split() for line in Path(trial['input']).read_text().splitlines()[1:]]
 invalid=[float(x[0]) for x in events if float(x[3])==0]
 assert not invalid or first<min(invalid)
 assert all(x['level']=='1' for x in rows if float(x['elapsed_s'])>=first)
 assert int((r/(trial['name']+'.exit')).read_text())==0
 out.append(dict(name=trial['name'],status='PASS',first_engaged_s=first,revocation_at_s=min(invalid) if invalid else None,active_through_contact=True))
(root/'runner-recorded-assessment.json').write_text(json.dumps(dict(status='PASS',scope='Actual recorded target and interval replay into production policy with rebased clocks/HOME epoch and stand-state feedback at nominal 50 Hz; no robot dynamics or collision proof',results=out),indent=2)+'\n')
print(out)
