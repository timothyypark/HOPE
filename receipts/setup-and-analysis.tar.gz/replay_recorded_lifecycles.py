from pathlib import Path
import csv,gzip,hashlib,io,json,subprocess,sys
sys.path.insert(0,'/workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/test')
from lifecycle_observer import verify_lifecycle
root=Path('/workspace/.cloud-setup/v2-simulation-verification');old=Path('/workspace/.cloud-setup/v2-incoming')
out=root/'historical-lifecycle-replay';out.mkdir(exist_ok=False)
def stream(p):
 p=p if p.exists() else p.with_name(p.name+'.gz');return gzip.open(p,'rt') if p.suffix=='.gz' else p.open()
cases=[('campaign-06-repetition-5',old/'qualification-06/repeated-campaign/repetition-5/reacquisition_chain_300_ON_REFRESH_zero'),('post-pacing-delayed-150',old/'reacquisition-pacing-regressions/reacquisition_delayed_150')]
results=[]
for name,folder in cases:
 raw=json.load(stream(folder/'result.raw.json'))
 with stream(folder/'result-hope_planner_cpp_node.stages') as f:
  metadata=dict(p.split('=') for p in f.readline()[1:].split());stages=list(csv.DictReader(f,delimiter='\t'))
 assert int(metadata['overwritten'])==0 and int(metadata['total'])==len(stages)
 by_source={r['stamp_ns']:r for r in raw['source']['rows']}
 for r in raw['source']['rows']:
  if r.get('fault') and 'wire_stamp_ns' in r:by_source.setdefault(r['wire_stamp_ns'],r)
 observations={r['ns']:r for r in raw['observations']}
 payload=[];observed=[]
 for r in stages:
  stamp=int(r['source_ns']);sequence=int(r['sequence'])
  if r['stage']=='planner_reject' and r['reason']=='SOURCE_UNQUALIFIED':
   payload.append(f'R {stamp} {sequence}\n')
  elif r['stage']=='pipeline_observed':
   source=by_source[stamp];ball=next(p for p in source['poses'] if p['name']=='Ball')
   valid=observations[stamp]['orientation_valid']
   payload.append(f'O {stamp} {sequence} '+' '.join(f'{v:.17g}' for v in ball['position']+ball['quaternion_wxyz'])+f' {int(valid)}\n');observed.append(r)
 data=''.join(payload);(out/(name+'.input')).write_text(data)
 process=subprocess.run([str(root/'lifecycle_recorded_replay')],input=data,text=True,capture_output=True)
 (out/(name+'.csv')).write_text(process.stdout);(out/(name+'.stderr')).write_text(process.stderr)
 process.check_returncode();replayed=list(csv.DictReader(io.StringIO(process.stdout)))
 result=dict(case=name,original_exception=raw['exception'],records=len(replayed),input_sha256=hashlib.sha256(data.encode()).hexdigest())
 try:
  assert len(replayed)==len(observed)
  transitions=[]
  for a,b in zip(replayed,observed):
   assert a['source_ns']==b['source_ns'] and a['sequence']==b['sequence']
   assert a['generation']==b['generation'] and a['original_reason']==b['reason'],(a,b)
   transitions.append({**b,'stage':a['state'],'reason':a['reason']})
  result['all_recorded_states_matched']=True
  result['lifecycle']=verify_lifecycle(raw['source']['rows'],dict(total=len(transitions),overwritten=0),transitions,raw['traces'],{int(r[0]) for r in raw['decoded']})
  result['status']='PASS'
 except Exception as error:result.update(status='FAIL',exception=repr(error))
 results.append(result);print(name,result['status'],result.get('exception'),flush=True)
(out/'result.json').write_text(json.dumps(dict(scope='Replay exact recorded pipeline inputs and source-fault revocations; require every generation and original reason to match before applying the corrected observer; original raw verdicts retained',results=results),indent=2)+'\n')
