import json, sys
from pathlib import Path
sys.path.insert(0,'/workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/test')
from lifecycle_observer import verify_lifecycle
from qualification_accounting import read_stages
root=Path('/workspace/.cloud-setup/v2-simulation-verification/lifecycle-consumers-01')
results=[]
for p in sorted(root.glob('*/result.raw.json')):
    raw=json.loads(p.read_text());meta,rows=read_stages(p.parent/'result-lifecycle.stages')
    try:
        evidence=verify_lifecycle(raw['source']['rows'],meta,rows,raw['traces'],{int(x[0]) for x in raw['decoded']})
    except AssertionError as error:evidence={'status':'FAIL','reason':str(error)}
    results.append({'name':p.parent.name,'result':evidence})
    print(p.parent.name,evidence['status'],evidence.get('reason',''))
(root/'corrected-observer-replay.json').write_text(json.dumps({'original_verdicts_preserved':True,
    'new_oracle_source':'cd39971','replay_results':results},indent=2)+'\n')
