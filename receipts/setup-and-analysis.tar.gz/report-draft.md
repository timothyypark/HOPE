# V2 simulation verification — current assessment

The observer correction and simulation verification are implemented. This is not yet a claim of complete incoming-flight coverage. Historical lost incoming commands remain distinct from harmless skipped updates and the accepted timing deviation.

Qualified source: `9603464` on `feature/v2-incoming-validity-continuous-dropin`; original iteration baseline: `0fb3542`. The new raw run is `qualification-01`. Its raw verdicts are preserved, including failures. The earlier evidence branch is unchanged.

## What this iteration changed

- Added an explicit acceptance manifest that records the user's acceptance of the historical 54.731069 ms forecast publication, keeps expiry/identity/invalidation checks, and evaluates physical-flight usefulness separately from per-observation coverage.
- Replaced latest-status polling as the lifecycle oracle with a complete, source- and generation-matched transition trace. Instrumentation is default-off; its bounded buffer is flushed only at shutdown. Negative controls must reject missing acquisition, rejection, quarantine, B acquisition/decode, obsolete commands, and incomplete evidence.
- Added a reproducible per-flight audit and controls that detect an absent flight, incorrect decoded target, insufficient lead, and incorrect contact time. New packet receipts retain every sample timestamp for future prefix diagnosis.
- Added independent ball-truth simulation through the actual V2 coordinator/adapter, existing racket planner and actual schema-4/5 decoder, plus a replay in the supplied A3 MuJoCo scene. Production racket-planning behavior is unchanged.

## Verification

| Check | Observed result |
|---|---|
| Native C++ | 25/25 groups pass |
| ASan + UBSan | 25/25 groups pass |
| Independent outgoing numerical reference | pass |
| Legacy and premerge V2 parity | pass; see raw counts |
| Fresh focused reacquisition consumers | 14/14 pass |
| Observer, outcome-audit and scope unit controls | 23/23 pass |
| Native conversion simulation | 162/162 checks pass; 81/81 physical scenarios have a usable command; 159 commands and 3 justified early abstentions |
| Supplied A3 MuJoCo scene | 159/159 outgoing-ball replays pass |
| Full ROS | planner 131/132, messages 2/2, bringup 25/27 |
| Instrumentation on/off comparison | pending |
| Exact historical lifecycle replay | pending |
| Existing repeated campaign | pending 160 trials |
| Incoming repeated campaign | pending 90 trials |
| Actual Runner/ONNX lifecycle comparison | pending |

The sole planner-suite raw failure is `integrated_chain_150_ON_REFRESH`: global source cadence was 139.656 Hz versus requested 150 Hz. The largest source gap was 331.480 ms immediately after the first startup sample, before the first declared ball flight at 0.8 s. Both scored flights had independently checked usable decoded targets (25 and 36 commands). This does not establish the requested source rate; it establishes that this particular startup failure did not lose either scored flight. Bringup flake8/pep257 failures are inherited, with no added lint signatures.

## Simulation scope and measurements

The frozen grid covers speeds 5/10/12 m/s, unknown/zero/known spin, three lateral positions, fixed/per-ball/stable-per-ball planes and two declared source cutoffs. The native probe supplies HOME and selected plane to production components; separate actual ROS tests exercise runtime selection, packet transport and decoding.

Maximum committed-contact error was 0.4933 mm and 0.05491 ms. Adapter position/velocity/time errors were zero; decoder position error was at most floating-point roundoff (1.12e-16 m). Independently reconstructed legacy-impact outgoing landing error was 0.6239 mm; the supplied MuJoCo scene's maximum landing error was 3.6477 mm.

The existing managed racket planner uses speed-dependent restitution, unlike the separate validated-return backend. The checker uses that declared law and independently integrates the reconstructed outgoing velocity. The original stricter validated-return reference check remains in qualification. Three early known-spin prefixes correctly abstained because their event-order uncertainty overlapped; each physical scenario also produced a valid command at its declared later cutoff. This is not used to excuse a missing committed ROS flight.

MuJoCo ran the supplied A3 scene with the robot pinned, starting the ball at the converted contact with independently reconstructed outgoing velocity. It tested ball flight, net clearance and landing. It did not execute a policy-driven robot swing or a racket collision. The original serve scene's drag fit was explicitly overlaid with the pinned incoming-planner fit before scoring. Unknown-spin reference cases use a zero-spin plant with withheld orientation; these checks do not establish accuracy for arbitrary unobserved spin or physical measurement noise.

## Historical coverage dispositions

All eight retained existing-backend campaign failures and the relevant full-ROS failures were audited using independent offered flights, actual decoder receipts, >=80 ms receiver lead, <=20 mm contact-position error and <=10 ms contact-time error. Each offered flight in these cases had a usable command. Completion of lifecycle and simulation gates supports a no-runtime-change decision for these static reference flights; the old per-observation verdicts remain intact.

The four original profiles remain explicit: `base_yaw_chain_150_0`, `review_chain_300_12_unknown`, `review_chain_150_12_zero`, and `review_refresh_300_10_unknown`. In the fresh full ROS run they passed raw coverage at 39/41, 40/40, 20/20 and 149/149 epochs respectively. The historical 36/39 result is preserved and separately assessed at ten useful flights out of ten.

The seven historical incoming campaign failures consist of six missed-command cases and the accepted forecast-latency deviation. The full ROS baseline has one additional missed-command case. Each missed-command case remains nine usable flights out of ten, with no removal from the denominator:

- Two missing packets are reproduced by replaying the actual offered source gaps (36.783 ms and 48.084 ms). Independent gap-free controls produce ten packets.
- The full-ROS missing packet is reproduced using the actual relay-delivered history; offered-source and gap-free controls produce ten packets. This establishes an effect of the retained delivery loss without guessing its OS/transport cause.
- Three prefix rejections include earlier observations received after the 30 ms qualification deadline. Packet endpoint/count evidence and typed receipt histories are retained. This does not authorize relaxing history qualification or packet matching.
- One immutable packet was rejected 46.229 ms after its source cutoff, including 40.846 ms after freeze. Its expiry rejection is correct, but the flight still lost its only useful command.

A recovery extension remains a scope question: making a fresh command attempt before acceptance must preserve one accepted command per flight, exact causal cutoffs for each attempt, HOME/plane identity, invalidation, and expiry. No such recovery has been silently enabled in this verification change.

## Preserved development failures

The first lifecycle-instrumented run failed because the initial oracle expected rejection to retain the acquisition generation; actual invalidation retires that generation. A second oracle correction accounts for deliberately altered fault timestamps. Original failed receipts remain, followed by corrected replay and a fresh 14/14 run.

The first conversion run used the wrong (constant) restitution law for the managed legacy racket planner. Its failed receipts remain; the corrected law and early-prefix uncertainty criteria were declared before the successful new run. Missing MuJoCo Python dependencies and diagnostic replay-parser mistakes are retained as development attempts, not presented as qualification failures or hidden retries.
