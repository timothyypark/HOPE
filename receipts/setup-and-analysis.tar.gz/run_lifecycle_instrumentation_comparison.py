from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/workspace/.cloud-setup/v2-simulation-verification');q=root/'qualification-01'
assert (q/'aggregate.exit').exists(), 'Run after the frozen campaigns, not concurrently'
repo=Path('/workspace/HOPE-v2-incoming')
def git(*args):return subprocess.check_output(['git','-c',f'safe.directory={repo}','-C',str(repo),*args],text=True).strip()
assert not git('status','--porcelain')
out=root/'lifecycle-instrumentation-comparison';out.mkdir(exist_ok=False)
wrapper=out/'disabled/hope_planner_cpp_node';wrapper.parent.mkdir()
binary=q/'build/hope_planner_cpp/hope_planner_cpp_node'
wrapper.write_text('#!/usr/bin/python3\nimport os,sys\nargs=["test.lifecycle_trace_path:=\\\"\\\"" if x.startswith("test.lifecycle_trace_path:=") else x for x in sys.argv[1:]]\nos.execv('+repr(str(binary))+',['+repr(str(binary))+']+args)\n')
wrapper.chmod(0o755)
old=json.loads((root/'lifecycle-consumers-02/plan.json').read_text())
trials=[]
for name in ['reacquisition_delayed_150','reacquisition_chain_300_ON_REFRESH_zero']:
 row=next(r for r in old['trials'] if r['name']==name)
 for enabled in [True,False]:
  cmd=row['command'][:];cmd.remove('--stage-accounting')
  cmd[cmd.index('--planner')+1]=str(binary if enabled else wrapper)
  cmd[cmd.index('--decoder')+1]=str(q/'build/hope_planner_cpp/hope_integrated_runner_probe')
  cmd[cmd.index('--bringup')+1]=str(q/'install/hope_bringup/lib/hope_bringup')
  folder=out/(name+('-enabled' if enabled else '-disabled'));folder.mkdir()
  cmd[cmd.index('--output')+1]=str(folder/'result.json')
  trials.append(dict(profile=name,enabled=enabled,command=cmd,environment=row['environment'],folder=str(folder)))
freeze=dict(source=git('rev-parse','HEAD'),declared_ns=time.time_ns(),trials=trials,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),wrapper_sha256=hashlib.sha256(wrapper.read_bytes()).hexdigest(),contract='Raw disabled runs must fail the missing-trace oracle. Compare independent B-flight outcomes, source health and measured latency; no claim of full lifecycle proof without the trace.')
(out/'plan.json').write_text(json.dumps(freeze,indent=2)+'\n')
sys.path.insert(0,str(repo/'hope_ws/src/hope_planner_cpp/scripts/flight_prediction_validation'))
from coverage_outcome_audit import audit
results=[]
for trial in trials:
 folder=Path(trial['folder'])
 with (folder/'process.log').open('w') as log:p=subprocess.run(trial['command'],env={**os.environ,**trial['environment']},stdout=log,stderr=subprocess.STDOUT)
 (folder/'process.exit').write_text(str(p.returncode)+'\n')
 raw=json.loads((folder/'result.raw.json').read_text());source=raw['source'];by={r['stamp_ns']:r for r in source['rows']};decoded={int(r[0]) for r in raw['decoded']}
 generations=[];flights=[]
 for i in range(10):
  commands=[t for t in raw['traces'] if int(t['source_time_ns']) in by and by[int(t['source_time_ns'])]['round']==i and by[int(t['source_time_ns'])]['opportunity']=='B']
  gens={int(t['physical_shot']) for t in commands};ok=bool(commands) and len(gens)==1 and any(int(t['command_sequence']) in decoded for t in commands)
  flights.append(dict(flight=i,commands=len(commands),decoded=sum(int(t['command_sequence']) in decoded for t in commands),valid=ok))
  generations.append(next(iter(gens)) if len(gens)==1 else -1)
 lifecycle=raw.get('lifecycle',{})
 expected_oracle=lifecycle.get('status')=='PASS' if trial['enabled'] else lifecycle.get('status')=='FAIL' and 'lifecycle trace' in lifecycle.get('exception','')
 spin=trial['command'][trial['command'].index('--spin')+1]
 useful=audit('reacquisition_'+spin,folder/'result.raw.json')
 comparison_ok=useful['assessment']!='CONFIRMED_DEFECT' and all(r['valid'] for r in flights) and all(b>a for a,b in zip(generations,generations[1:])) and source['cadence']['valid'] and expected_oracle
 result=dict(profile=trial['profile'],enabled=trial['enabled'],raw_exit=p.returncode,raw_exception=raw.get('exception'),lifecycle=lifecycle.get('status'),useful_flight_assessment=useful,flights=flights,generations=generations,cadence=source['cadence'],comparison='PASS' if comparison_ok else 'FAIL')
 results.append(result);print(trial['profile'],trial['enabled'],result['comparison'],flush=True)
assert git('rev-parse','HEAD')==freeze['source'] and not git('status','--porcelain')
(out/'summary.json').write_text(json.dumps(dict(status='PASS' if all(r['comparison']=='PASS' for r in results) else 'FAIL',results=results),indent=2)+'\n')
