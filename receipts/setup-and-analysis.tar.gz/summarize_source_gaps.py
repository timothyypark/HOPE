from pathlib import Path
import json
root=Path('/workspace/.cloud-setup/v2-simulation-verification')
q=root/'qualification-01'
assert (q/'aggregate.exit').exists()
rows=[]
for trial in [json.loads(s) for s in (q/'repeated-campaign/outcomes.jsonl').read_text().splitlines()]:
 if trial['status']=='PASS':continue
 path=Path(trial['output']);path=path if path.is_dir() else path.parent
 raw=json.loads((path/'result.raw.json').read_text())
 sources=sorted(raw['source']['rows'],key=lambda r:r['stamp_ns'])
 before,after=max(zip(sources,sources[1:]),key=lambda pair:pair[1]['stamp_ns']-pair[0]['stamp_ns'])
 rows.append(dict(profile=trial['profile'],repetition=trial['repetition'],exception=raw.get('exception'),
                  cadence=raw['source'].get('cadence'),largest_source_gap_ms=(after['stamp_ns']-before['stamp_ns'])/1e6,
                  before=before,after=after))
(root/'current-failure-source-gaps.json').write_text(json.dumps(rows,indent=2)+'\n')
