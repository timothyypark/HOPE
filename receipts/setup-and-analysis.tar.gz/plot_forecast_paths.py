from pathlib import Path
import csv,json,sys,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,'/workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/test')
from integrated_producer_chain import flight
root=Path('/workspace/.cloud-setup/v2-simulation-verification')
cases=json.loads((root/'conversion-02/manifest.json').read_text())['cases']
commands={int(r['id']):r for r in csv.DictReader((root/'forecast-path-commands.csv').open())}
paths={}
for r in csv.DictReader((root/'forecast-paths.csv').open()):paths.setdefault(int(r['id']),[]).append(r)
assert (root/'forecast-path-commands.csv').read_bytes()==(root/'conversion-02/probe.csv').read_bytes()
out=root/'forecast-path-review';out.mkdir(exist_ok=False)
metrics=[]
for c in cases:
 before,after,bounce=flight(c['speed'],c['spin'])
 points=paths.get(c['id'],[])
 times=np.array([c['cutoff_s']+float(p['dt']) for p in points])
 predicted=np.array([[float(p[n]) for n in ['x','y','z']] for p in points])
 usable=times<=c['crossing_s']
 times=times[usable];predicted=predicted[usable]
 truth=np.array([(before.sol(t) if t<bounce else after.sol(t))[:3] for t in times])
 if len(truth):truth[:,1]=c['y']
 errors=np.linalg.norm(predicted-truth,axis=1) if len(truth) else []
 metrics.append(dict(id=c['id'],waypoints_before_contact=len(times),maximum_position_error_m=float(max(errors)) if len(errors) else None))
 if c['speed']==10 and c['spin']=='zero' and c['y']==-.7 and c['cutoff_s']==.18:
  fig,axes=plt.subplots(1,3,figsize=(14,4))
  full_times=np.linspace(0,c['crossing_s'],300)
  full=np.array([(before.sol(t) if t<bounce else after.sol(t))[:3] for t in full_times]);full[:,1]=c['y']
  row=commands[c['id']];contact=np.array([float(row[n]) for n in ['cx','cy','cz']]);normal=np.array([float(row[n]) for n in ['nx','ny','nz']])
  for axis,index,label in [(axes[0],2,'z above table (m)'),(axes[1],1,'y (m)')]:
   axis.plot(full[:,0],full[:,index],label='Independent ball truth',color='#555555')
   axis.plot(predicted[:,0],predicted[:,index],'--',label='Actual V2 forecast',color='#0072b2',linewidth=2)
   axis.scatter(contact[0],contact[index],marker='x',label='Converted contact')
   axis.quiver(contact[0],contact[index],normal[0]*.12,normal[index]*.12,angles='xy',scale_units='xy',scale=1)
   axis.axvline(c['plane_x'],color='gray',linestyle=':');axis.set(xlabel='x (m)',ylabel=label);axis.grid(alpha=.2)
  axes[2].plot(times,np.array(errors)*1000);axes[2].set(xlabel='Flight time (s)',ylabel='Forecast position error (mm)');axes[2].grid(alpha=.2)
  axes[0].legend(fontsize=8);fig.suptitle(['Fixed','Per-ball','Stable per-ball'][c['mode']]+' plane: actual V2 trajectory and converted target (no robot dynamics)')
  fig.tight_layout();fig.savefig(out/f"forecast-mode-{c['mode']}.png",dpi=150);plt.close(fig)
(out/'metrics.json').write_text(json.dumps(dict(scope='Supplemental visual/trajectory metrics, not a new retrospective acceptance gate',command_receipts_byte_identical=True,probe_source_sha256=hashlib.sha256((root/'forecast_path_probe.cpp').read_bytes()).hexdigest(),probe_binary_sha256=hashlib.sha256((root/'forecast_path_probe').read_bytes()).hexdigest(),results=metrics),indent=2)+'\n')
