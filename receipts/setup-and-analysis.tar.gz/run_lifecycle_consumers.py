import hashlib, json, os, subprocess, time
from pathlib import Path

root = Path('/workspace/.cloud-setup/v2-simulation-verification')
destination = root/'lifecycle-consumers-01'
destination.mkdir(exist_ok=False)
old = json.loads(Path('/workspace/.cloud-setup/v2-incoming/reacquisition-pacing-regressions/plan.json').read_text())
repo = '/workspace/HOPE-v2-incoming'
def git(*args):
    return subprocess.check_output(['git','-c',f'safe.directory={repo}','-C',repo,*args], text=True).strip()
sha = git('rev-parse','HEAD')
assert not git('status','--porcelain')
trials = []
for row in old['trials']:
    cmd = row['command'][:]
    cmd[cmd.index('--planner')+1] = str(root/'ros-build/hope_planner_cpp_node')
    out = destination/row['name']/'result.json';out.parent.mkdir()
    cmd[cmd.index('--output')+1] = str(out)
    trials.append(dict(name=row['name'],command=cmd,environment=row['environment']))
plan = dict(source=sha,declared_ns=time.time_ns(),trials=trials,
            planner_sha256=hashlib.sha256((root/'ros-build/hope_planner_cpp_node').read_bytes()).hexdigest())
(destination/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
results = []
for row in trials:
    folder=destination/row['name']
    with (folder/'process.log').open('w') as log:
        proc=subprocess.run(row['command'],env={**os.environ,**row['environment']},stdout=log,stderr=subprocess.STDOUT)
    (folder/'process.exit').write_text(str(proc.returncode)+'\n')
    data=json.loads((folder/'result.json').read_text())
    raw=json.loads((folder/'result.raw.json').read_text())
    results.append(dict(name=row['name'],exit=proc.returncode,status=data.get('status'),
                        lifecycle=raw.get('lifecycle'),exception=raw.get('exception')))
    print(row['name'],proc.returncode,raw.get('lifecycle',{}).get('status'),flush=True)
assert git('rev-parse','HEAD') == sha and not git('status','--porcelain')
(destination/'summary.json').write_text(json.dumps(dict(source=sha,executed=len(results),
    passed=sum(r['exit']==0 for r in results),lifecycle_passed=sum(r['lifecycle'].get('status')=='PASS' for r in results),results=results),indent=2)+'\n')
