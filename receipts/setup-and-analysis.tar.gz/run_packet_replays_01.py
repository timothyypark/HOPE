from pathlib import Path
import csv,gzip,io,json,subprocess,sys
import yaml
import numpy as np
sys.path.insert(0,'/workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/test')
from integrated_producer_chain import flight
root=Path('/workspace/.cloud-setup/v2-simulation-verification');old=Path('/workspace/.cloud-setup/v2-incoming/qualification-06')
out=root/'packet-replays-01';out.mkdir(exist_ok=False)
def stream(p):
 p=p if p.exists() else p.with_name(p.name+'.gz');return gzip.open(p,'rt') if p.suffix=='.gz' else p.open()
config=yaml.safe_load(Path('/workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/config/model21800_flight_packetizer.yaml').read_text())['hope_ball_flight_packetizer']['ros__parameters']
config={k:v for k,v in config.items() if isinstance(v,(int,float,bool))}
header=str(len(config))+'\n'+''.join(f'{k} {float(v):.17g}\n' for k,v in config.items())
cases=[(1,'300_per_ball_zero'),(1,'360_per_ball_unknown'),(3,'150_per_ball_unknown'),(4,'150_per_ball_zero'),(4,'150_stable_per_ball_zero'),(4,'360_stable_per_ball_zero'),(0,'300_stable_per_ball_zero')]
report=[]
for rep,profile in cases:
 folder=old/(f'incoming-campaign/repetition-{rep}' if rep else 'build/hope_planner_cpp')/('incoming_chain_'+profile)
 raw=json.load(stream(folder/'raw.json'));src=raw['source'];rows=src['rows'];by={r['source_ns']:r for r in rows};origin=src['origin_ns']
 with stream(folder/'relay.tsv') as f:
  next(f);stages=list(csv.DictReader(f,delimiter='\t'))
 delivered={int(r['source_ns']):int(r['wall_ns']) for r in stages if r['stage']=='typed_published'}
 spin=profile.rsplit('_',1)[-1];rate=int(profile.split('_')[0]);before,after,bounce=flight(10,spin)
 for variant in ['offered','relay','ideal_cadence_control']:
  samples=[]
  if variant=='ideal_cadence_control':
   for n in range(round(10*rate)):
    t=n/rate;ordinal=int(np.floor((t-.5)/.9));phase=t-.5-ordinal*.9
    if 0<=ordinal<10 and phase<src['crossing_s']+.025:
     state=before.sol(phase) if phase<bounce else after.sol(phase);stamp=origin+round(t*1e9)
     samples.append((stamp,stamp,state))
  else:
   for row in rows:
    if row['present'] and (variant=='offered' or row['source_ns'] in delivered):
     stamp=row['source_ns'];samples.append((stamp,stamp if variant=='offered' else delivered[stamp],row['state']))
  payload=header+''.join(f'{stamp} {receipt} '+ ' '.join(f'{x:.17g}' for x in state[:3])+f' {state[6]:.17g} {int(spin!="unknown")}\n' for stamp,receipt,state in samples)
  name=f'{rep}-{profile}-{variant}'
  (out/(name+'.input')).write_text(payload)
  process=subprocess.run([str(root/'packet_replay')],input=payload,text=True,capture_output=True)
  (out/(name+'.csv')).write_text(process.stdout);(out/(name+'.stderr')).write_text(process.stderr)
  process.check_returncode()
  packets=list(csv.DictReader(io.StringIO(process.stdout)))
  produced=sorted({int(np.floor((int(p['cutoff_ns'])-origin)*1e-9/.9-.5/.9))+1 for p in packets})
  result=dict(repetition=rep,profile=profile,variant=variant,packets=len(packets),produced_flights=produced,missing_flights=sorted(set(range(1,11))-set(produced)))
  report.append(result);print(result,flush=True)
(out/'result.json').write_text(json.dumps(dict(scope='Actual protected IncomingTrajectory/AdaptiveFlightCommit with exact configuration declarations; offered/relay replay and independent no-gap control; no original opportunity excluded',results=report),indent=2)+'\n')
