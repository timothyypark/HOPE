#!/usr/bin/env bash
set -uo pipefail
root=/workspace/.cloud-setup/v2-simulation-verification
q=$root/qualification-01
test -f "$q/aggregate.exit" || exit 2
source "$q/install/setup.bash"
run() {
  local name=$1
  shift
  "$@" > "$root/$name.log" 2>&1
  local status=$?
  echo "$status" > "$root/$name.exit"
  echo "$name exit=$status"
  return "$status"
}
run historical-lifecycle-build g++ -std=c++17 -O2 \
  -I/workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/include -I/usr/include/eigen3 \
  "$root/lifecycle_recorded_replay.cpp" "$q/native/libhope_native_core.a" -lpthread \
  -o "$root/lifecycle_recorded_replay"
if [[ $? == 0 ]]; then
  sha256sum "$root/lifecycle_recorded_replay.cpp" "$root/lifecycle_recorded_replay" \
    "$q/native/libhope_native_core.a" > "$root/historical-lifecycle-replay-input-sha256.txt"
  run historical-lifecycle-replay python3 "$root/replay_recorded_lifecycles.py"
fi
run lifecycle-instrumentation-comparison python3 "$root/run_lifecycle_instrumentation_comparison.py"
run campaign-outcome-assessment python3 "$root/assess_completed_campaigns.py"
if [[ $? == 0 ]]; then
  run decoder-lifetime-assessment python3 "$root/audit_decoder_lifetimes.py"
fi
run current-failure-source-gaps python3 "$root/summarize_source_gaps.py"
