from pathlib import Path
import hashlib,json
repo=Path('/workspace/HOPE-v2-incoming');package=repo/'hope_ws/src/hope_planner_cpp';out=Path('/workspace/.cloud-setup/v2-simulation-verification')
node=(package/'src/flight_packetizer_node.cpp').read_text();params=(package/'include/hope_planner_cpp/future_contact_parameters.hpp').read_text()
helpers=params[params.index('inline FutureContactConfig'):params.rindex('}  // namespace hope_planner_cpp')]
config=node[node.index('IncomingTrajectoryConfig declare_trajectory_config'):node.index('}  // namespace\n')]
source='''#include "hope_planner_cpp/incoming_trajectory.hpp"
#include <iostream>
#include <iomanip>
#include <map>
namespace rclcpp {
struct Node {
 std::map<std::string,double> parameters;
 template<class T> T declare_parameter(const std::string& key,T fallback) {
  auto it=parameters.find(key);return it==parameters.end()?fallback:static_cast<T>(it->second);
 }
};
}
namespace hope_planner_cpp {
'''+helpers+config+'''}
using namespace hope_planner_cpp;
int main(){
 rclcpp::Node node;int parameters;std::cin>>parameters;
 for(int i=0;i<parameters;++i){std::string key;double value;std::cin>>key>>value;node.parameters[key]=value;}
 IncomingTrajectory trajectory(declare_trajectory_config(node),declare_prediction_config(node));
 trajectory.set_prediction_x_hit(.08);
 std::cout<<std::setprecision(17)<<"phase,source_ns,epoch,packet_count,first_ns,cutoff_ns,net_cross_s,commit_s\\n";
 auto emit=[&](const IncomingTrajectoryUpdate& update,std::int64_t stamp){
  if(!update.snapshot_ready)return;
  const auto& s=update.snapshot;
  std::cout<<static_cast<int>(trajectory.phase())<<','<<stamp<<','<<s.trajectory_epoch<<','<<s.sample_count<<','
    <<s.samples[0].source_time_ns<<','<<s.latest_sample()->source_time_ns<<','
    <<s.one_shot.net_cross_source_time_s<<','<<s.one_shot.commit_source_time_s<<'\\n';
 };
 BallSample sample;double angle;int orientation;std::int64_t timer=0;
 while(std::cin>>sample.source_time_ns>>sample.receipt_wall_ns>>sample.position.x()>>sample.position.y()>>sample.position.z()>>angle>>orientation){
  if(!timer)timer=sample.receipt_wall_ns;
  while(timer<sample.receipt_wall_ns){emit(trajectory.poll(timer*1e-9),timer);timer+=1000000;}
  sample.source_time_s=sample.source_time_ns*1e-9;
  sample.orientation_valid=true;
  sample.orientation=orientation?Eigen::Quaterniond(Eigen::AngleAxisd(angle,Vec3::UnitY())):Eigen::Quaterniond::Identity();
  emit(trajectory.observe(sample),sample.source_time_ns);
 }
 return std::cin.eof()?0:2;
}
'''
(out/'packet_replay.cpp').write_text(source)
(out/'packet-replay-provenance.json').write_text(json.dumps(dict(purpose='Deterministic actual IncomingTrajectory replay with configuration declarations extracted verbatim; transport callback scheduling is not reconstructed',source_files={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [package/'src/flight_packetizer_node.cpp',package/'include/hope_planner_cpp/future_contact_parameters.hpp',package/'src/incoming_trajectory.cpp',package/'src/adaptive_flight_commit.cpp']},replay_sha256=hashlib.sha256(source.encode()).hexdigest()),indent=2)+'\n')
