from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/workspace/.cloud-setup/v2-simulation-verification');q=root/'qualification-01'
repo=Path('/workspace/HOPE-v2-incoming');out=root/'runner-recorded-replay';out.mkdir(exist_ok=False)
cases=[('early-expiry','repetition-2/incoming_chain_300_per_ball_zero',3),
       ('late-forecast','repetition-4/incoming_chain_360_stable_per_ball_unknown',8)]
trials=[]
for name,relative,identity in cases:
 path=q/'incoming-campaign'/relative/'raw.json';raw=json.loads(path.read_text())
 received=raw['received'];wires={int(w[14]):w for w in received['commands'] if int(w[15])==identity}
 rows=[];seen=set()
 for d in received['decoded']:
  seq=int(d[0])
  if seq in wires and seq not in seen:
   seen.add(seq);rows.append((d[13]+d[14]*1e-9,wires[seq]))
 rows.sort();assert rows and rows[0][1][1]==1
 origin=rows[0][0];end=max(w[10] for _,w in rows if w[1])-origin
 for control in [False,True]:
  selected=[r for r in rows if r[1][1] or not control]
  label=name+('-valid-only-control' if control else '-recorded-revocation')
  text=f'{origin:.17g} {end:.17g}\n'+''.join(f'{stamp-origin:.17g} {len(wire)} '+' '.join(f'{v:.17g}' for v in wire)+'\n' for stamp,wire in selected)
  file=out/(label+'.input');file.write_text(text)
  trials.append(dict(name=label,input=str(file),source=str(path),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),input_sha256=hashlib.sha256(text.encode()).hexdigest(),source_wire_flight=identity,valid_only_control=control,events=len(selected),contact_from_first_receipt_s=end))
manifest=dict(declared_ns=time.time_ns(),purpose='Check whether recorded valid commands actually engage the supplied production policy and whether observed revocations precede or follow engagement. Diagnostic extension: no numerical conversion gate or old verdict is changed.',scope='Original target geometry, velocities, spin, flight/revision identities and receiver-arrival intervals. Rebase absolute clocks and HOME epoch to the live software fixture; base position is the recorded (-.5,-.7625,.95). Sample at real 50 Hz with stand-state feedback; no joint/robot dynamics.',trials=trials,binary_sha256=hashlib.sha256((root/'runner_recorded_command_probe').read_bytes()).hexdigest())
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
results=[]
for trial in trials:
 with (out/(trial['name']+'.csv')).open('w') as output,(out/(trial['name']+'.log')).open('w') as error:
  proc=subprocess.run([str(root/'runner_recorded_command_probe'),str(repo/'hope_training/whole_body_tracking/checkpoints/policy.onnx'),str(repo/'hope_training/whole_body_tracking/checkpoints/deploy.yaml'),trial['input']],stdout=output,stderr=error)
 (out/(trial['name']+'.exit')).write_text(str(proc.returncode)+'\n')
 lines=(out/(trial['name']+'.log')).read_text().splitlines();summary=next((l for l in reversed(lines) if l.startswith('RECORDED_REPLAY ')),None)
 results.append(dict(name=trial['name'],exit=proc.returncode,summary=summary))
 print(trial['name'],proc.returncode,summary,flush=True)
(out/'result.json').write_text(json.dumps(dict(scope=manifest['scope'],results=results),indent=2)+'\n')
