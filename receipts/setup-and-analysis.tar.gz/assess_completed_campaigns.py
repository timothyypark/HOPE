from pathlib import Path
import json,sys
sys.path.insert(0,'/workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/scripts/flight_prediction_validation')
from coverage_outcome_audit import audit
root=Path('/workspace/.cloud-setup/v2-simulation-verification');q=root/'qualification-01'
assert (q/'aggregate.exit').exists(), 'Assess after the complete timed campaigns'
results=[]
for campaign,expected,incoming in [('repeated-campaign',160,False),('incoming-campaign',90,True)]:
 paths=sorted((q/campaign).glob('repetition-*/*/result.json'));assert len(paths)==expected,(campaign,len(paths))
 for path in paths:
  raw_path=path.with_name('raw.json' if incoming else 'result.raw.json')
  raw_result=json.loads(path.read_text());raw=json.loads(raw_path.read_text());profile=path.parent.name
  outcome=audit(profile,raw_path,incoming)
  useful=outcome['assessment']!='CONFIRMED_DEFECT'
  lifecycle=raw.get('lifecycle',{}).get('status')
  if not useful:state='CONFIRMED_DEFECT'
  elif 'reacquisition' in profile and lifecycle!='PASS':state='INCONCLUSIVE_LIFECYCLE'
  elif raw_result.get('status')=='PASS':state='PASS'
  else:state='USABLE_COMMANDS_PRESENT_REQUIRES_RAW_FAILURE_REVIEW'
  result=dict(campaign=campaign,repetition=path.parent.parent.name,profile=profile,raw_status=raw_result.get('status'),raw_exception=raw_result.get('exception'),raw_checks=raw_result.get('checks',raw_result.get('gates')),lifecycle=lifecycle,outcome=outcome,current_assessment=state)
  results.append(result)
  print(campaign,path.parent.parent.name,profile,state,flush=True)
summary={name:dict(executed=sum(r['campaign']==name for r in results),raw_passed=sum(r['campaign']==name and r['raw_status']=='PASS' for r in results),flights=sum(r['outcome']['expected_flights'] for r in results if r['campaign']==name),useful_flights=sum(sum(f['usable_commands']>0 for f in r['outcome']['flights']) for r in results if r['campaign']==name)) for name in ['repeated-campaign','incoming-campaign']}
(root/'campaign-outcome-assessment.json').write_text(json.dumps(dict(scope='Every declared trial; independent useful-flight accounting; separate raw and current verdicts; no historical timing acceptance automatically applied to new failures',summary=summary,results=results),indent=2)+'\n')
print(summary)
