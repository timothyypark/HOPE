export GIT_CONFIG_COUNT=3
export GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/workspace/HOPE-pr85-conflict-resolution
export GIT_CONFIG_KEY_1=safe.directory GIT_CONFIG_VALUE_1=/workspace/HOPE-pr85-upstream-baseline
export GIT_CONFIG_KEY_2=safe.directory GIT_CONFIG_VALUE_2=/workspace/HOPE-integrated-reacquisition-spin
