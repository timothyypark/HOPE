from pathlib import Path
from collections import Counter
import xml.etree.ElementTree as E
import json,subprocess,re,hashlib
r=Path('/workspace/HOPE-pr85-conflict-resolution');e=Path('/workspace/.cloud-setup/pr85-integration');d=r/'hope_ws/src/hope_planner_cpp/docs'
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
pins=json.loads((e/'pins.json').read_text());ledger=json.loads((e/'conflict-ledger.json').read_text());lint={}
for name in ('flake8','pep257'):
 counts=[]
 for label in ('upstream','merged'):
  xml=e/label/'build/hope_bringup/test_results/hope_bringup'/f'{name}.xunit.xml';c=Counter()
  for t in E.parse(xml).getroot().iter('testcase'):
   for f in t.findall('failure'):
    c[re.sub(r':\d+(?::\d+)?\)',')',t.attrib['name'])+' '+f.attrib.get('message','')]+=1
  counts.append(c)
 lint[name]=dict(upstream=sum(counts[0].values()),merged=sum(counts[1].values()),added=list((counts[1]-counts[0]).elements()),removed=list((counts[0]-counts[1]).elements()))
 assert not lint[name]['added'],lint[name]
(e/'lint-comparison.json').write_text(json.dumps(lint,indent=2)+'\n')
shared=json.loads((e/'shared-paths.json').read_text())['auto_merged_shared']
auto=[]
for p in shared:
 exact=not git('diff',pins['base'],'--',p)
 auto.append(dict(path=p,upstream_exact=exact,verification='Exact target bytes' if exact else 'Minimal V2 additions reviewed; source scope, clean build, legacy parity and V2 cutoff/receiver regressions'))
profiles={}
for p in (e/'merged/build/hope_planner_cpp').glob('*.json'):
 if p.stem.startswith(('integrated_chain_','reacquisition_chain_','review_chain_')):
  v=json.loads(p.read_text());profiles[p.stem]={k:v[k] for k in ('status','command_coverage','command_denominator','covered_command_epochs','actual_decoder_ms') if k in v}
receipt=dict(status='INTEGRATION_CHECKPOINT_TESTED_NOT_TIMING_QUALIFIED',pins=pins,conflicts=ledger,auto_merged_shared=auto,
 build={'upstream_exit':int((e/'upstream/build.exit').read_text()),'merged_exit':int((e/'merged/build.exit').read_text())},
 native_groups=dict(passed=19,total=19),upstream_ros=dict(messages='2/2',planner='19/19',bringup='24/26; inherited flake8 and pep257 failures'),
 merged_ros=dict(messages='2/2',selected_functional_planner='44/44',installed_profiles='6/6',bringup='25/27; inherited flake8 and pep257 failures'),
 actual_aggregate={'upstream_test_result_exit':int((e/'upstream/test-result.exit').read_text()),'merged_test_result_exit':int((e/'merged/functional-test-result.exit').read_text())},
 lint=lint,deployment_tests=dict(passed=83,subtests=148),legacy_parity=json.loads((e/'upstream-parity.json').read_text()),
 v2_cutoff_parity=json.loads((e/'v2-cutoff-parity.json').read_text()),v2_command_parity=json.loads((e/'v2-command-parity.json').read_text()),installed_profiles=profiles,
 github=dict(api='Blocked by environment proxy (403), including escalated read; public page and fetched PR ref agree with pins',public_state='OPEN',reviews='No reviews on retrieved public page',draft=False,required_checks='Unavailable via blocked API; not assumed passing',push='PENDING'),
 historical_evidence=dict(path='/workspace/.cloud-setup/reacquisition-spin/reacquisition-spin-evidence.tar.gz',bytes=15579488,sha256='fb23fd72ccdff4bb38e5c9820937ad1ee22421f53c15421cbeecb067c42ea3c8'),
 planner_timing_qualified=False,planner_software_qualified=False,simulation_qualified=False,physically_qualified=False,deployment_authorized=False)
# Avoid duplicating the 701 large fixture arrays in this concise checkpoint receipt.
receipt['legacy_parity'].pop('fixtures',None)
(d/'integrated_planner_pr85_integration.json').write_text(json.dumps(receipt,indent=2)+'\n')
lines=['# PR85 integration checkpoint','',
'PR85 is integrated locally against upstream `nightly_built` at `'+pins['base']+'`. This checkpoint preserves legacy and V2 functionality; timing qualification remains open. The merge is an ordinary two-parent merge, with no history rewrite or upstream merge.', '',
'## Pins and conflict resolution','',
'- Original PR head: `'+pins['head']+'`.','- Common ancestor: `'+pins['common']+'`.','- Native merge: **18 real conflicts** (13 content, 5 add/add); stage blobs, index and conflict diff retained in the evidence.',
'- Existing HOPE and nohope worktrees were preserved. Current deployment/Foxglove files have no remaining diff from the selected target.',
'- Every shared auto-merge is listed in the JSON companion. The planner entry point differs from upstream only by opt-in V2 dispatch/ownership/destruction; legacy stays the default.',
'- Keep upstream `rcl_interfaces`, session-home installation, runtime-plane tests, `max_sample_gap_s`, `single_flight_only`, packer/receiver headers and deployment profiles. Link the new `test_planner_runtime_plane` target to the V2 runtime because it compiles the shared entry point.',
'- Keep V2 physics and shadow configuration separate from upstream legacy PPQ004 overrides. V2 does not add support for runner schemas 4/5 or shared-HOME runtime controls. The existing schema-2 absolute contact deadline and height conversion pass against current receiver headers.', '',
'| Conflicted path | Resolution |','| --- | --- |']
for x in ledger:lines.append('| `'+x['path']+'` | '+x['upstream_intent']+' '+x['resolution']+' |')
lines+=['','## Executed verification','',
'- Both clean ROS builds passed, including all targets compiling `planner_node.cpp`, replay/export tools, standalone forecaster and installed messages.',
'- Native C++: 19/19 groups, including the selected upstream receiver, restart, retention and session-home tests.',
'- Upstream ROS: messages 2/2, planner 19/19, bringup 24/26. Merged: messages 2/2, 44/44 selected planner functional groups and 6/6 installed producer/decoder profiles, bringup 25/27. The exhaustive repeated matrix is Step 2, not this checkpoint.',
'- Legacy: 701/701 exact matches against the current upstream target. Historical comparisons keep their original pin and receipts; hashes were not forced back to obsolete source.',
'- V2: ten recorded input streams produce exact state/event/covariance/readiness/generation outputs before and after merging, excluding compute duration. All 144 outgoing command rows match exactly; the outgoing sweep binary hashes also match.',
'- Deployment regressions: 83 tests and 148 subtests passed.',
'- The source-scope guard uses `test/fixtures/pr85_upstream_sources.json`, which records the explicit historical-to-current SHA mapping. Original historical fixture hashes and receipts remain unchanged.',
'- Bringup lint remains failing. After formatting only the touched test argument list, there are no added normalized findings relative to current upstream (file/rule/exact source-message retained, line/column coordinates ignored). Pep257 is unchanged; flake8 removes several findings. Actual colcon test-result exit is 1 for both trees.',
'- An initial wrapper invocation ran discovery from the wrong directory; it was corrected before the selected run. Initial XML tests could not fetch the external ROS schema; both trees were rerun using the existing local schema catalog. These setup failures are not passing qualification runs.',
'', '## Timing and delivery','',
'The two prior failing profiles were run once on the integrated build before performance changes. Both passed; recovery coverage was 160/160 and the direct producer profile was 157/160. This does not close the historical 92.5% and 91.25% failures or replace the five-repetition campaign. Full software qualification remains false.',
'', 'GitHub API requests are blocked by the environment proxy; the public PR page and fetched PR ref confirm the recorded target/head and open status. Push and GitHub test-merge verification are recorded after this checkpoint. No PR draft-state change, upstream merge, live output, simulation or robot actuation is requested or performed.']
(d/'integrated_planner_pr85_integration.md').write_text('\n'.join(lines)+'\n')
# Inventory the actual target-relative delivery; preserve old receipts independently.
manifest=d/'integrated_planner_pr85_scope_manifest.json'
old=json.loads(manifest.read_text());old={x['path']:x for x in old['files']}
paths=set(git('diff','--name-only',pins['base']).splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
files=[]
for p in sorted(paths):
 files.append(old.get(p,dict(path=p,owner='PR85 integration verification',why_needed='Document and verify reconciliation with the selected upstream target.',tests=['flight_v2_scope','integration checkpoint'])))
manifest.write_text(json.dumps(dict(base=pins['base'],premerge=pins['head'],files=files),indent=2)+'\n')
print(len(files),'scoped files; no new lint findings')
