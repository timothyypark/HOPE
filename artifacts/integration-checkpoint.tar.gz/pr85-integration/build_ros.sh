#!/usr/bin/env bash
set -eo pipefail
repo=$1
out=$2
mkdir -p "$out"
unset AMENT_PREFIX_PATH COLCON_PREFIX_PATH CMAKE_PREFIX_PATH ROS_PACKAGE_PATH PYTHONPATH LD_LIBRARY_PATH
source /opt/ros/jazzy/setup.bash
cd "$repo/hope_ws"
set +e
MAKEFLAGS=-j2 colcon --log-base "$out/log" build --base-paths src ../NatNet2ROS2/src/motion_capture_tracking_interfaces --build-base "$out/build" --install-base "$out/install" --packages-select hope_msgs hope_planner_cpp hope_bringup motion_capture_tracking_interfaces --executor sequential --cmake-args -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release > "$out/build.log" 2>&1
result=$?
echo "$result" > "$out/build.exit"
tail -35 "$out/build.log"
exit "$result"
