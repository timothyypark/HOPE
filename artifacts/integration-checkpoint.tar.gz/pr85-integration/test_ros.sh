#!/usr/bin/env bash
set -eo pipefail
source /workspace/.cloud-setup/pr85-integration/git_env.sh
out=$1
repo=$2
cd "$repo/hope_ws"
[[ $(cat "$out/build.exit") == 0 ]]
unset AMENT_PREFIX_PATH COLCON_PREFIX_PATH CMAKE_PREFIX_PATH ROS_PACKAGE_PATH PYTHONPATH LD_LIBRARY_PATH
source /opt/ros/jazzy/setup.bash
source "$out/install/setup.bash"
export ROS_DOMAIN_ID=193 ROS_LOCALHOST_ONLY=1
export XML_CATALOG_FILES=/workspace/.cloud-setup/ros-schema-catalog.xml
set +e
colcon --log-base "$out/test-log" test --build-base "$out/build" --install-base "$out/install" --packages-select hope_msgs hope_planner_cpp hope_bringup --executor sequential --event-handlers console_direct+ > "$out/test.log" 2>&1
result=$?
echo "$result" > "$out/test.exit"
colcon test-result --test-result-base "$out/build" --verbose > "$out/test-result.log" 2>&1
echo "$?" > "$out/test-result.exit"
tail -20 "$out/test.log"
exit "$result"
