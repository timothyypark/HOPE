cmake --build /workspace/.cloud-setup/v2-incoming/qualification-02/sanitized -j4 
