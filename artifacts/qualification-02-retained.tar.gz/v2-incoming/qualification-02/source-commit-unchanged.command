cmp /workspace/.cloud-setup/v2-incoming/qualification-02/code-sha.txt /workspace/.cloud-setup/v2-incoming/qualification-02/final-code-sha.txt 
