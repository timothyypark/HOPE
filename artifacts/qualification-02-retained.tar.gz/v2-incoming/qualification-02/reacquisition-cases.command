/workspace/.cloud-setup/v2-incoming/qualification-02/native/test_reacquisition_spin --gtest_output=xml:/workspace/.cloud-setup/v2-incoming/qualification-02/reacquisition-cases.xml 
