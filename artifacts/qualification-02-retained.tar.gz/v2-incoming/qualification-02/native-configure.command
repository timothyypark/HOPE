cmake -S /workspace/HOPE-v2-incoming/hope_ws/src/hope_planner_cpp/test/native -B /workspace/.cloud-setup/v2-incoming/qualification-02/native -DCMAKE_BUILD_TYPE=Release 
