test \! -s /workspace/.cloud-setup/v2-incoming/qualification-02/final-worktree-status.txt 
