/workspace/.cloud-setup/v2-incoming/qualification-02/native/test_reacquisition_counterexamples --gtest_output=xml:/workspace/.cloud-setup/v2-incoming/qualification-02/counterexample-cases.xml 
