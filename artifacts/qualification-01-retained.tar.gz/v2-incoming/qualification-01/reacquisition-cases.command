/workspace/.cloud-setup/v2-incoming/qualification-01/native/test_reacquisition_spin --gtest_output=xml:/workspace/.cloud-setup/v2-incoming/qualification-01/reacquisition-cases.xml 
