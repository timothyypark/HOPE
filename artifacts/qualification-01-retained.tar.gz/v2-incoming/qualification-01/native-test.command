ctest --test-dir /workspace/.cloud-setup/v2-incoming/qualification-01/native --output-on-failure 
