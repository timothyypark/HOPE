/workspace/.cloud-setup/v2-incoming/qualification-01/native/test_base_pose_contract --gtest_output=xml:/workspace/.cloud-setup/v2-incoming/qualification-01/base-cases.xml 
