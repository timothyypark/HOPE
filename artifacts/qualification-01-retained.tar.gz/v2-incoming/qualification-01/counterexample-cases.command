/workspace/.cloud-setup/v2-incoming/qualification-01/native/test_reacquisition_counterexamples --gtest_output=xml:/workspace/.cloud-setup/v2-incoming/qualification-01/counterexample-cases.xml 
