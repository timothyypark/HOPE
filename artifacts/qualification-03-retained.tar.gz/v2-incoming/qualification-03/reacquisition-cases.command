/workspace/.cloud-setup/v2-incoming/qualification-03/native/test_reacquisition_spin --gtest_output=xml:/workspace/.cloud-setup/v2-incoming/qualification-03/reacquisition-cases.xml 
