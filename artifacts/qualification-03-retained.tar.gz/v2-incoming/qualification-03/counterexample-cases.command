/workspace/.cloud-setup/v2-incoming/qualification-03/native/test_reacquisition_counterexamples --gtest_output=xml:/workspace/.cloud-setup/v2-incoming/qualification-03/counterexample-cases.xml 
