#!/bin/bash
source /opt/ros/jazzy/setup.bash
source /workspace/.cloud-setup/reacquisition-spin/qualification-verified/install/setup.bash
export ROS_DOMAIN_ID=193 ROS_LOCALHOST_ONLY=1
export PYTHONPATH=/workspace/HOPE-integrated-reacquisition-spin/hope_ws/src/hope_planner_cpp/test:$PYTHONPATH
evidence=/workspace/.cloud-setup/reacquisition-spin
built=$evidence/qualification-verified/build/hope_planner_cpp
bringup=$evidence/qualification-verified/install/hope_bringup/lib/hope_bringup
python3 "$evidence/timing-repeat/reacquisition_producer_chain.py" --planner "$built/hope_planner_cpp_node" --decoder "$built/hope_integrated_runner_probe" --bringup "$bringup" --rate 300 --policy FOLLOW_POSE --spin unknown --output "$evidence/timing-repeat/result.json" > "$evidence/timing-repeat/console.log" 2>&1
echo $? > "$evidence/timing-repeat/exit.txt"
python3 "$evidence/review-timing-repeat/integrated_producer_chain.py" --planner "$built/hope_planner_cpp_node" --decoder "$built/hope_integrated_runner_probe" --bringup "$bringup" --rate 300 --speed 10 --spin zero --output "$evidence/review-timing-repeat/result.json" > "$evidence/review-timing-repeat/console.log" 2>&1
echo $? > "$evidence/review-timing-repeat/exit.txt"
