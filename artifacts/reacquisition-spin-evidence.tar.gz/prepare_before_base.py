import pathlib,re,importlib.util,json
R=pathlib.Path('/workspace/HOPE-integrated-reacquisition-spin');E=pathlib.Path('/workspace/.cloud-setup/reacquisition-spin')
p=R/'hope_ws/src/hope_bringup/scripts/base_pose_contract.py';sp=importlib.util.spec_from_file_location('base_contract',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
s=(R/'hope_ws/src/hope_planner_cpp/src/integrated_planner_runtime.cpp').read_text();expr=re.search(r'base.orientation=(.*);',s).group(1)
(E/'before_base.cpp').write_text('''#include "hope_planner_cpp/target_turn_guard.hpp"
#include <gtest/gtest.h>
#include <vector>
using namespace hope_planner_cpp;
Eigen::Quaterniond actual_consumer(const std::vector<double>& w){return '''+expr+''';}
TEST(BaseBefore,E03_ProducerNonzeroYawTurnContract){
''')
import math
with (E/'before_base.cpp').open('a') as f:
 for yaw in [0,30,-30,50]:
  q=[math.cos(math.radians(yaw)/2),0,0,math.sin(math.radians(yaw)/2)]
  w=m.pose_to_base_flat([-.43,-.7,0],q,[0,0,0],[1,0,0,0],.76,sequence=1,source_sec=1800000000,source_nsec=0,tracking_quality=1,flags=63,calibration_id=1,world_frame_id=1)
  f.write('{std::vector<double> w={'+','.join(map(repr,w))+'};auto q=actual_consumer(w);auto d=check_target_turn(Vec3(.15,-.7,.3),Vec3(-.43,-.7,0),q,true);EXPECT_NEAR(d.base_yaw_deg,'+str(yaw)+',1e-9);EXPECT_EQ(d.allowed,'+str(abs(yaw)<=40).lower()+');}\n')
 f.write('}\n')
(E/'before-base-expression.json').write_text(json.dumps({'source':'e9bf015','actual_consumer_expression':expr,'producer':'base_pose_contract.py:pose_to_base_flat','yaws':[0,30,-30,50]},indent=2))
