from pathlib import Path
R=Path('/workspace/HOPE-integrated-reacquisition-spin/hope_ws/src/hope_planner_cpp')
def edit(path,old,new):
 p=R/path;s=p.read_text();assert old in s,(path,old[:80]);p.write_text(s.replace(old,new,1))
edit('include/hope_planner_cpp/flight_spin_estimator.hpp','  void push(const BallSample& sample) noexcept;', '''  void push(const BallSample& sample) noexcept;
  // Change relative origin without changing source cutoffs or angular evidence.
  void rebase_time(double offset_s) noexcept;''')
edit('src/flight_spin_estimator.cpp','void FlightSpinEstimator::append(','''void FlightSpinEstimator::rebase_time(double offset) noexcept {
  if (have_previous_) previous_time_s_ -= offset;
  for (std::size_t i=0;i<increment_count_;++i) increments_[i].end_time_s -= offset;
}

void FlightSpinEstimator::append(''')
edit('include/hope_planner_cpp/trusted_spin.hpp','// Owned by one physical shot.', '''struct SpinReadiness {
  std::string state = "UNAVAILABLE", reason = "no_qualified_angular_increments";
  std::size_t increments = 0;
  double span_s = 0;
  std::int64_t measurement_time_ns = 0;
};
// Owned by one physical shot.''')
edit('include/hope_planner_cpp/trusted_spin.hpp','  const EffectiveSpin &value() const { return value_; }', '''  const EffectiveSpin &value() const { return value_; }
  SpinReadiness readiness() const {
    const auto estimate = estimator_.estimate();
    SpinReadiness r;
    r.increments = estimate.retained_increments;
    r.span_s = estimate.sample_span_s;
    r.measurement_time_ns = value_.measurement_time_ns;
    r.reason = estimate.reason;
    if (value_.usable()) {
      r.state = value_.mode == EffectiveSpinMode::MEASURED ? "READY_MEASURED" :
          value_.mode == EffectiveSpinMode::CONTACT_PROPAGATED ? "CONTACT_PROPAGATED" : "HELD";
      r.reason = value_.provenance;
    } else if (r.increments) r.state = "COLLECTING";
    return r;
  }
  void rebase_time(double offset) {
    estimator_.rebase_time(offset);
    if (last_time_s_) *last_time_s_ -= offset;
    for (auto &entry : history_) entry.sample.source_time_s -= offset;
  }''')
edit('include/hope_planner_cpp/flight_state_v2.hpp','  bool game_legality_advisory = false;', '''  bool game_legality_advisory = false;
  // Explicit opt-in for long-running integrated sessions; standalone retains
  // its explicit-boundary default and service_armed is always respected.
  bool automatic_rearm = false;''')
edit('include/hope_planner_cpp/flight_state_v2.hpp','  const std::string &reason() const { return reason_; }', '''  const std::string &reason() const { return reason_; }
  const std::string &rejection_reason() const { return rejection_reason_; }
  std::int64_t rejection_source_ns() const {
    return rejection_fence_ ? rejection_fence_->source_time_ns : 0;
  }
  const char *acquisition_state() const {
    if (active()) return "ACTIVE_SHOT";
    if (!rejected_latch_) return "COLLECTING_INITIAL_SHOT";
    if (rearm_candidate_) return "COLLECTING_NEW_SHOT";
    return rejection_reason_ == "source_clock_discontinuity" ? "WAIT_SOURCE_RESET" : "WAIT_NEW_FLIGHT";
  }
  SpinReadiness spin_readiness() const {
    return active() ? spin_.readiness() : candidate_spin_.readiness();
  }
  const EffectiveSpin &acquisition_spin() const { return acquisition_spin_; }
  std::int64_t acquisition_spin_cutoff_ns() const { return acquisition_spin_cutoff_ns_; }''')
edit('include/hope_planner_cpp/flight_state_v2.hpp','private:\n  void reclassify();', '''private:
  friend class FlightPipeline;
  // One owner for quarantine/fresh-launch evidence and candidate segmentation.
  bool collect_candidate(const BallSample &);
  void rebase_times(std::int64_t origin_ns);
  void reclassify();''')
edit('include/hope_planner_cpp/flight_state_v2.hpp','  TrustedSpin spin_;','''  TrustedSpin spin_, candidate_spin_;
  EffectiveSpin acquisition_spin_;
  std::int64_t acquisition_spin_cutoff_ns_ = 0;
  std::optional<BallSample> rejection_fence_, candidate_last_, quiet_anchor_;
  std::string rejection_reason_;
  bool rearm_candidate_ = false;''')
edit('src/flight_state_v2.cpp','  if (s.game_legality_advisory) out << ";game_legality_advisory";', '''  if (s.game_legality_advisory) out << ";game_legality_advisory";
  if (s.automatic_rearm) out << ";automatic_rearm";
  out << ";bounded-causal-candidate-spin-v2";''')
edit('src/flight_state_v2.cpp','  double *target = nullptr;', '''  if (key == "automatic_rearm_enabled") {
    if (value != 0 && value != 1) throw std::invalid_argument("automatic_rearm_enabled must be 0 or 1");
    s.automatic_rearm = value == 1;
    return;
  }
  double *target = nullptr;''')
edit('src/flight_state_v2.cpp','  if (rejected_latch_ && evidence == BoundaryEvidence::ACQUISITION)\n    return;', '''  if (rejected_latch_ && evidence == BoundaryEvidence::ACQUISITION &&
      !(settings_.automatic_rearm && rearm_candidate_)) return;
  const bool acquisition = evidence == BoundaryEvidence::ACQUISITION;
  auto angular_history = candidate_spin_;''')
edit('src/flight_state_v2.cpp','  rejected_latch_ = false;\n  samples_.clear();', '''  rejected_latch_ = false;
  rearm_candidate_ = false;
  rejection_fence_.reset(); rejection_reason_.clear();
  candidate_last_.reset(); quiet_anchor_.reset();
  acquisition_spin_ = {}; acquisition_spin_cutoff_ns_ = 0;
  samples_.clear();''')
edit('src/flight_state_v2.cpp','      observe(std::move(sample));\n}', '''      observe(std::move(sample));
  if (acquisition && active()) spin_ = std::move(angular_history);
  candidate_spin_.reset();
}''')
edit('src/flight_state_v2.cpp','void ShotContext::invalidate(const std::string &why) {\n  ++generation_;', '''void ShotContext::invalidate(const std::string &why) {
  // Retain only a source-identity/time fence, never the old estimation ledger.
  if (!samples_.empty()) rejection_fence_ = samples_.back();
  rejection_reason_ = why;
  candidate_last_ = rejection_fence_;
  quiet_anchor_.reset(); rearm_candidate_ = false;
  candidate_spin_.reset(); acquisition_spin_ = {}; acquisition_spin_cutoff_ns_ = 0;
  ++generation_;''')
edit('src/flight_state_v2.cpp','bool ShotContext::observe(BallSample s) {', '''bool ShotContext::collect_candidate(const BallSample &s) {
  if (!s.clock_mapping_valid || !std::isfinite(s.clock_uncertainty_s) ||
      s.clock_uncertainty_s < 0 || s.clock_uncertainty_s > .001) return false;
  if (rejected_latch_ && rejection_fence_ && !compatible(*rejection_fence_,s)) return false;
  if (candidate_last_ && (s.source_time_ns <= candidate_last_->source_time_ns ||
      !compatible(*candidate_last_,s))) return false;
  const double gap = candidate_last_ ? double((static_cast<long double>(s.source_time_ns)-
      candidate_last_->source_time_ns)*1e-9L) : 0;
  bool quiet_launch = false, angular_boundary = false;
  if (quiet_anchor_ && (s.position-quiet_anchor_->position).norm() > settings_.held_displacement_m) {
    const double quiet_span = candidate_last_ ? double((static_cast<long double>(candidate_last_->source_time_ns)-
        quiet_anchor_->source_time_ns)*1e-9L) : 0;
    quiet_launch = quiet_span >= settings_.held_span_s;
    angular_boundary = quiet_span >= settings_.qualification_span_s;
    quiet_anchor_ = s;
  }
  if (!quiet_anchor_) quiet_anchor_ = s;
  candidate_last_ = s;
  bool new_opportunity = false;
  if (rejected_latch_ && settings_.automatic_rearm && !rearm_candidate_) {
    if (!rejection_fence_ || rejection_reason_ == "source_clock_discontinuity") return false;
    new_opportunity = gap > config_.max_tracking_gap_s || quiet_launch;
    if (!new_opportunity) return false;
    rearm_candidate_ = true;
    reason_ = gap > config_.max_tracking_gap_s ? "rearm_qualified_source_gap" : "rearm_held_to_launch";
  }
  if (new_opportunity || gap > config_.gap_warning_s || angular_boundary ||
      s.position.z() <= config_.physics.radius + .03) {
    candidates_.clear(); candidate_spin_.reset();
    quiet_anchor_ = s;
  }
  candidate_spin_.observe(s);
  candidates_.push_back(s);
  while (candidates_.size() > settings_.candidate_capacity) candidates_.pop_front();
  return true;
}
void ShotContext::rebase_times(std::int64_t origin) {
  if (samples_.empty()) return;
  const double offset = samples_.front().source_time_s - double(
      (static_cast<long double>(samples_.front().source_time_ns)-origin)*1e-9L);
  for (auto &s : samples_) s.source_time_s -= offset;
  for (auto &s : candidates_) s.source_time_s -= offset;
  spin_.rebase_time(offset); candidate_spin_.rebase_time(offset);
}
bool ShotContext::observe(BallSample s) {''')
edit('src/flight_state_v2.cpp','      rejected_latch_ = false;\n    }\n  }\n  if (!active()) {', '''      // Standalone retains the established active-gap recovery contract.
      // Integrated automatic rearm goes through the same fenced helper as an
      // already-rejected shot, rather than clearing the latch here.
      if (!settings_.automatic_rearm) rejected_latch_ = false;
    }
  }
  if (!active()) {''')
edit('src/flight_state_v2.cpp','''    if (!candidates_.empty() &&
        (s.source_time_ns <= candidates_.back().source_time_ns ||
         !compatible(candidates_.back(), s)))
      return false;
    candidates_.push_back(s);
    while (candidates_.size() > settings_.candidate_capacity)
      candidates_.pop_front();''','''    collect_candidate(s);''')
edit('src/flight_state_v2.cpp','  if (active() || rejected_latch_ || settings_.service_armed ||','''  if (active() || (rejected_latch_ && !(settings_.automatic_rearm && rearm_candidate_)) || settings_.service_armed ||''')
edit('src/flight_state_v2.cpp','  TrustedSpin candidate_spin;','  // Candidate angular history is independently retained across short dynamic windows.')
edit('src/flight_state_v2.cpp','    if (point.source_time_ns <= b.source_time_ns) candidate_spin.observe(point);','')
edit('src/flight_state_v2.cpp','  const auto &spin = candidate_spin.value();','  const auto spin = candidate_spin_.at(b.source_time_ns);\n  const auto cutoff = b.source_time_ns;')
edit('src/flight_state_v2.cpp','''    reason_ = spin.usable() ? "acquisition_qualified_spin_model_residual"
                           : "acquisition_position_only_model_residual_spin_unobserved";''','''    reason_ = spin.usable() ? "acquisition_qualified_spin_model_residual" :
        candidate_spin_.readiness().state == "COLLECTING" ? "SPIN_COLLECTING_MODEL_NOT_YET_SUPPORTED" :
        "MODEL_UNSUPPORTED_WHILE_SPIN_UNKNOWN";''')
edit('src/flight_state_v2.cpp','  const auto boundary = a.source_time_ns;','  const auto boundary = candidates_.front().source_time_ns;')
edit('src/flight_state_v2.cpp','''        "ballistic_acquisition_incomplete_history");
  return active();''','''        "ballistic_acquisition_incomplete_history");
  if (active()) { acquisition_spin_ = spin; acquisition_spin_cutoff_ns_ = cutoff; }
  return active();''')
edit('src/flight_state_v2.cpp','  reason_ = "restored_shot_checkpoint";', '''  candidate_spin_.reset(); candidate_last_.reset(); quiet_anchor_.reset();
  rejection_fence_.reset(); rejection_reason_.clear(); rearm_candidate_ = false;
  acquisition_spin_ = {}; acquisition_spin_cutoff_ns_ = 0;
  reason_ = "restored_shot_checkpoint";''')
edit('src/flight_state_v2.cpp','''    TrustedSpin replay_spin;
    for (const auto &s : shot_.samples()) {''','''    if (settings_.automatic_rearm && !shot_.samples().empty()) {
      origin_ = shot_.samples().front().source_time_ns;
      shot_.rebase_times(*origin_);
    }
    for (const auto &s : shot_.samples()) {''')
a='''      replay_spin.observe(s);
      for (const auto &event : shot_.events())
        if (event.kind == PhysicalEventKind::TABLE &&
            event.status == EventStatus::CONFIRMED &&
            event.event_time_ns <= s.source_time_ns)
          replay_spin.contact(event.id, event.event_time_ns, event.pre.velocity,
                              config_.physics);
      // Never assign the acquisition window's final spin to earlier intervals.
      tracker_.set_effective_spin(replay_spin.value());'''
edit('src/flight_state_v2.cpp',a,'''      // Historical lookup includes candidate angular evidence older than the
      // short dynamic suffix, and never pulls a future measurement backward.
      tracker_.set_effective_spin(shot_.spin_at(s.source_time_ns));''')
