from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess,xml.etree.ElementTree as ET
E=Path('/workspace/.cloud-setup/reacquisition-spin');F=E/'qualification-verified';B=E/'baseline-e9bf015';R=Path('/workspace/HOPE-integrated-reacquisition-spin')
def read(path):return json.loads(path.read_text())
def compact(d):return {k:v for k,v in d.items() if k not in ['source','wire','decoded','traces','statuses','physical_rows']}
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert (F/'aggregate.exit').exists(),'Verification is still running'
exits={p.stem:int(p.read_text()) for p in F.glob('*.exit')}
assert all(v==0 for k,v in exits.items() if k not in ['aggregate','ros-test-result','ros-test']),exits
packages={}
for pkg in ['hope_msgs','hope_planner_cpp','hope_bringup']:
 p=F/'build'/pkg;tag=(p/'Testing/TAG').read_text().splitlines()[0]
 tests=ET.parse(p/'Testing'/tag/'Test.xml').findall('.//Testing/Test')
 packages[pkg]={'groups':len(tests),'passed':sum(t.attrib['Status']=='passed' for t in tests),'failed':[t.findtext('Name') for t in tests if t.attrib['Status']!='passed']}
assert not packages['hope_msgs']['failed'],packages
assert sorted(packages['hope_planner_cpp']['failed'])==['flight_v2_ros_transport','reacquisition_chain_300_FOLLOW_POSE_unknown','review_chain_300_10_zero','review_source_cutoff_parity'],packages
assert sorted(packages['hope_bringup']['failed'])==['flake8','pep257'],packages
lint={}
for name in ['flake8','pep257']:
 def failures(root):
  path=root/'build/hope_bringup/test_results/hope_bringup'/(name+'.xunit.xml')
  return Counter((t.attrib['name'],f.attrib.get('message',''),f.text or '') for t in ET.parse(path).findall('.//testcase') for f in t.findall('failure'))
 before,after=failures(B),failures(F)
 assert before==after,(name,len(before),len(after))
 lint[name]={'failures':sum(after.values()),'exact_baseline_multiset_match':True,'multiset_sha256':hashlib.sha256(json.dumps(sorted(after.items())).encode()).hexdigest()}
cases={}
for name in ['review','reacquisition','counterexample','base']:
 root=ET.parse(F/(name+'-cases.xml')).getroot();ts=root.findall('.//testcase')
 assert all(t.find('failure') is None and t.attrib.get('status')=='run' for t in ts)
 cases[name]=[t.attrib['classname']+'.'+t.attrib['name'] for t in ts]
for gate in ['native-test','sanitized-test']:assert '100% tests passed, 0 tests failed out of 18' in (F/(gate+'.log')).read_text()
p=F/'build/hope_planner_cpp';matrix=[]
for path in sorted(p.glob('reacquisition_*.json')):
 if '.raw.' in path.name or path.stem=='reacquisition_source_cutoff_parity':continue
 d=read(path)
 if 'rounds' not in d:continue
 assert d['status']=='PASS' and d['command_coverage']>=.95 and len(d['rounds'])==10
 matrix.append({k:d[k] for k in ['rate_hz','plane_policy','spin','first_worker_delay_ms','cross_generation_discard_observed','command_coverage','command_denominator','covered_command_epochs','decoder_ms','resources']}|{'file':str(path.relative_to(E)),'rounds':len(d['rounds']),'A_launched':d['source']['launched_A'],'B_launched':d['source']['launched_B'],'B_generations':[r['B_generation'] for r in d['rounds']]})
assert len(matrix)==13,len(matrix)
parity=read(F/'legacy-parity.json');outgoing=read(F/'outgoing-reference.json');policy=read(F/'policy-contract.json')
assert sum(parity['fixture_counts'].values())==701 and parity['max_abs_difference']==0
assert outgoing['status']=='PASS' and outgoing['total_candidates']==144
receipt={'schema_version':1,'status':'IMPLEMENTED_FUNCTIONAL_PASS_TIMING_GATE_FAILED_ON_FIRST_RUN','scope':'G0–G5 continuation software, localhost synthetic source-to-decoder evidence','base_sha':(B/'code-sha.txt').read_text().strip(),'tested_sha':(F/'code-sha.txt').read_text().strip(),'worktree_clean_at_test_start':not (F/'worktree-status.txt').read_text().strip(),'implementation_complete':True,'software_complete':False,'simulation_qualified':False,'physically_qualified':False,'deployment_authorized':False,'evidence_root':str(E),'verification_root':str(F),'environment':(E/'environment.txt').read_text(),'repository_audit':read(E/'repository-audit.json'),'frozen_contract':read(E/'frozen-contract.json'),'gates':{'G0':'PASS: pinned baseline and E01/E02/E03 failures reproduced','G1':'PASS: RA01–RA08','G2':'PASS: SP01–SP09','G3':'PASS: BP01–BP05 and actual producer/decoder matrix','G4':'FUNCTIONAL_PASS_TIMING_GATE_FAILED: all 140 B opportunities recovered; 13/14 matrix cases passed, one 300 Hz coverage failure retained','G5':'NOT_FULLY_QUALIFIED: two first-run 300 Hz coverage failures (92.5%, 91.25%) below 95%; inherited lint failures unchanged','G6':'NOT_RUN: native Runner/plant absent, evaluation-only Arm B adapter outstanding','G7':'NOT_RUN: real data inventoried, no independently registered robot/clock/contact or operational approval'},'native_groups':18,'sanitized_groups':18,'cases':cases,'ros':packages,'baseline_lint':lint,'exit_status':exits,'baseline':read(E/'baseline-summary.json'),'installed_reacquisition_matrix':matrix,'source_cutoff_parity':read(p/'reacquisition_source_cutoff_parity.json'),'historical_source_cutoff_parity':read(E/'development/build/hope_planner_cpp/review_source_cutoff_parity.json'),'outgoing_reference':outgoing,'legacy_parity':{k:v for k,v in parity.items() if k!='fixtures'},'policy_contract':policy,'g6_readiness':read(E/'g6-readiness.json'),'real_data_inventory':read(E/'real-data-inventory.json'),'preserved_contracts':read(E/'preserved-contracts.json'),'source_file_hashes':read(E/'tested-source-files.json'),'timing_first_run':read(E/'coverage-first-run-analysis.json'),'timing_repeat':compact(read(E/'timing-repeat/result.json')),'review_timing_repeat':compact(read(E/'review-timing-repeat/result.json')),'actual_opportunity_audit':read(E/'actual-opportunity-audit.json'),'post_full_suite_corrections':{'sha':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'changes':['Explicit producer zero survives decode_observation; nonfinite and invalid-flag data still rejected','Transport output allowlist includes exact readiness diagnostic topic','Older parity test replays actual consumed prefixes from checkpoint observation ledgers; published/missing/tail source rows are separately retained','Repeated-chain assertions additionally require actual A acquisition and observed-under-table rejection'],'validation':{'targeted_transport_and_six_cutoff_cases':'post-review-tests.log: 3/3 groups PASS','reacquisition_cutoffs_and_scope':'post-final-cutoffs.log: 2/2 groups PASS'},'full_suite_repeated_after_corrections':False},'known_excluded_runs':['before-overrange-pilot used 300 rad/s beyond unchanged 20 rev/s; excluded','development quaternion oracle initially used unrounded seconds; corrected to actual source ns without loosening tolerance','qualification-final stopped after a test-only constructor compile error; retained, superseded by qualification-verified'],'publication':'Local review branch; no upstream PR action or live activation'}
(E/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'ros':packages,'matrix':len(matrix),'min_coverage':min(x['command_coverage'] for x in matrix),'worst_decoder_p95_ms':max(x['decoder_ms']['p95'] for x in matrix),'lint':lint},indent=2))
