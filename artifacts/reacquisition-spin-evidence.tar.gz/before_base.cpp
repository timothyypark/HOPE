#include "hope_planner_cpp/target_turn_guard.hpp"
#include <gtest/gtest.h>
#include <vector>
using namespace hope_planner_cpp;
Eigen::Quaterniond actual_consumer(const std::vector<double>& w){return Eigen::Quaterniond(w[11],w[8],w[9],w[10]).normalized();}
TEST(BaseBefore,E03_ProducerNonzeroYawTurnContract){
{std::vector<double> w={2.0,1.0,1.0,1800000000.0,0.0,-0.43,-0.7,0.76,1.0,0.0,0.0,0.0,1.0,63.0,1.0,1.0};auto q=actual_consumer(w);auto d=check_target_turn(Vec3(.15,-.7,.3),Vec3(-.43,-.7,0),q,true);EXPECT_NEAR(d.base_yaw_deg,0,1e-9);EXPECT_EQ(d.allowed,true);}
{std::vector<double> w={2.0,1.0,1.0,1800000000.0,0.0,-0.43,-0.7,0.76,0.9659258262890683,0.0,0.0,0.25881904510252074,1.0,63.0,1.0,1.0};auto q=actual_consumer(w);auto d=check_target_turn(Vec3(.15,-.7,.3),Vec3(-.43,-.7,0),q,true);EXPECT_NEAR(d.base_yaw_deg,30,1e-9);EXPECT_EQ(d.allowed,true);}
{std::vector<double> w={2.0,1.0,1.0,1800000000.0,0.0,-0.43,-0.7,0.76,0.9659258262890683,0.0,0.0,-0.25881904510252074,1.0,63.0,1.0,1.0};auto q=actual_consumer(w);auto d=check_target_turn(Vec3(.15,-.7,.3),Vec3(-.43,-.7,0),q,true);EXPECT_NEAR(d.base_yaw_deg,-30,1e-9);EXPECT_EQ(d.allowed,true);}
{std::vector<double> w={2.0,1.0,1.0,1800000000.0,0.0,-0.43,-0.7,0.76,0.9063077870366499,0.0,0.0,0.42261826174069944,1.0,63.0,1.0,1.0};auto q=actual_consumer(w);auto d=check_target_turn(Vec3(.15,-.7,.3),Vec3(-.43,-.7,0),q,true);EXPECT_NEAR(d.base_yaw_deg,50,1e-9);EXPECT_EQ(d.allowed,false);}
}
