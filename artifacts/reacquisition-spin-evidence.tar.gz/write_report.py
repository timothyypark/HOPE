from pathlib import Path
import json,shutil,subprocess
E=Path('/workspace/.cloud-setup/reacquisition-spin');R=Path('/workspace/HOPE-integrated-reacquisition-spin');D=R/'hope_ws/src/hope_planner_cpp/docs';d=json.loads((E/'receipt.json').read_text())
d['core_correction_implemented']=d.pop('implementation_complete')
(D/'integrated_planner_reacquisition_spin_qualification.json').write_text(json.dumps(d,indent=2)+'\n')
rows=[]
for m in d['installed_reacquisition_matrix']:
 rows.append(f"| {m['rate_hz']} | {m['plane_policy']} | {m['spin']} | {m['first_worker_delay_ms']} | {m['covered_command_epochs']}/{m['command_denominator']} ({100*m['command_coverage']:.2f}%) | {m['decoder_ms']['p95']:.3f} | {m['status']} |")
case_rows=[]
for group in ['reacquisition','base']:
 for name in d['cases'][group]:
  label=name.split('.')[1];ident,description=label.split('_',1)
  case_rows.append(f"| {ident} | {description.replace('_',' ')} | PASS |")
text=f'''# Reacquisition, spin readiness and base-contract qualification

The P1/P2/base-contract corrections are implemented. **Full software qualification
is still open:** two nominal 300 Hz runs missed the frozen 95% command-coverage
threshold. Both exact retries passed, but the original failures remain failures.
`software_complete`, `simulation_qualified`, `physically_qualified` and
`deployment_authorized` are **false**. No robot was actuated.

## Source and scope

- Exact continuation base: `{d['base_sha']}`.
- Clean full-suite source: `{d['tested_sha']}`.
- Final code/test correction source: `{d['post_full_suite_corrections']['sha']}`.
  This adds explicit-zero ROS decoding and corrects verification instrumentation.
  The affected transport/cutoff/graph tests were rerun; the entire full suite was
  not rerun after these changes. The native physics/CKF/rearm code is unchanged.
- Local branch: `feature/integrated-planner-reacquisition-spin-readiness`.
- Original HOPE, earlier review-fixes and nohope worktrees remain untouched.
  Upstream changes were fetched and audited, not silently merged into the pinned base.
- PR64 remains **closed, unmerged**, at historical head `9118a491`; no PR was
  reopened, retargeted or published. The new PR description is a local draft.

Audited HOPE upstream main is `8d24642474205f6cfb48263cd22896306feeac47`,
upstream nightly is `91aecabfd44cb258ac998158e724be9017d883a7`, and fork nightly
is `6616b1df795b6b5db242435fafc394295e0b45cf`. New upstream asset/serve/home/model
changes are separate from this implementation. nohope remains
`96e71c1adb217d14b925681173cebe00d8427f21`; its parent main is
`c2a627f26c957a079b5cc2586ab6cf49aae4a221` (3 parent-only / 9 fork-only commits).

The existing CKF6, deterministic physics coefficients, residual/uncertainty
thresholds, legacy solver/goldens/default YAMLs, policy artifacts and schemas
remain intact: runner schema 2, observation/context schema 2, forecast/packet
schema 3. The integrated profile enables automatic rearm; standalone defaults
it off. Source-qualified gap or held-to-launch evidence is required after a
rejection. Continuous rejected motion and wall-clock cooldown cannot rearm.
Candidate angular history is bounded independently of the short dynamic window
and queried no later than its midpoint. A supported position-only forecast may
start before measured spin. The actual base consumer now reads WXYZ. Explicit
valid producer zero survives ROS decoding; absent/nonfinite input stays invalid.

## Gates and results

| Gate | Result |
| --- | --- |
| G0 | PASS: clean baseline, named E01/E02/E03 failures, controls, frozen criteria |
| G1 | PASS: RA01–RA08, fresh generation/origin/CKF/events/spin and old-worker fences |
| G2 | PASS: SP01–SP09, causal quaternion-only spin, early position-only, true zero |
| G3 | PASS: BP01–BP05, real producer, rotated bases, actual decoder/110-D builder |
| G4 | Functional recovery PASS; timing NOT_FULLY_QUALIFIED (one new matrix case) |
| G5 | NOT_FULLY_QUALIFIED: two first-run coverage failures; corrections/retries below |
| G6 | NOT_RUN: native Runner and instrumented plant absent; evaluation-only Arm B outstanding |
| G7 | NOT_RUN: real recordings inventoried, independent robot/clock/impact evidence outstanding |

Before production edits, the exact `e9bf015` baseline passed 15 native groups,
15 ASan/UBSan groups, 26 historical review cases and 701 exact legacy parity
cases. ROS had 2/2 message groups, 66/67 planner groups, and 24/26 bringup groups.
The raw-scenario fixture failed twice: cold first publication delayed its source
by about 283 ms and omitted the first bounce. Its correction warms an explicitly
invalid observation before scored exposure; existing physics/assertions remain.
The corrected raw-scenario test passed the full run.

E01/E02 fail-before counterexamples reproduce rejection latching and in-range
quaternion-only acquisition starvation. E02 uses 30 m/s and 100 rad/s, with the
unchanged 20 rev/s limit, and a direct-omega positive control. An exploratory
300 rad/s case exceeded that limit and is **excluded**, with logs retained.
E03 compiles the actual baseline consumer expression against values emitted by
`pose_to_base_flat`: identity passes while ±30° and +50° reveal the defect.
`test/reacquisition_baseline_probe.py` reproduces these failures from the pinned
Git source and requires the named positive controls to pass.

The corrected full run passed **18/18 native groups**, **18/18 ASan/UBSan groups**,
all **26 historical review cases**, **17 RA/SP cases**, **5 BP cases**, and the
four before/after counterexample cases. The actual Python base producer passed
8 sign/yaw combinations. Two distinct policy artifacts passed 110-D metadata,
world-frame/term semantics and six finite CPU inference cases; this is not a
native Runner inspection or achieved paddle tracking claim.

All **701 legacy parity cases** matched with maximum absolute difference zero.
All **144 outgoing candidates** passed the independently integrated reference,
now explicitly `method='DOP853'`, rtol=2e-12, atol=2e-14. Maximum landing-position
error was {d['outgoing_reference']['max_position_error_m']:.16g} m, event-time
error {d['outgoing_reference']['max_event_time_error_s']:.16g} s, and analytic
impact closure error zero. The old reference label said DOP853 while invoking
SciPy's default RK45; that historical result is not relabeled as a DOP853 run.

The initial full ROS run had **96/100 planner groups pass**. Four failures are
retained:

1. `reacquisition_chain_300_FOLLOW_POSE_unknown`: 148/160 eligible epochs, 92.5%.
2. `review_chain_300_10_zero`: 146/160, 91.25%.
3. `review_source_cutoff_parity`: a 23.44 ms source pause followed by a 0.38 ms
   interval exposed a different consumed input prefix at the depth-one receiver.
   The corrected comparator reconstructs the actual prefix from checkpoint
   observation ledgers, retains the complete published stream and lists missing
   rows/uncovered tail rows. State/covariance/event tolerances are unchanged.
4. `flight_v2_ros_transport`: the exact output allowlist omitted the newly added
   shadow readiness diagnostic. It now names that exact topic; control-topic
   prohibitions remain.

The two corrected tests and the full ROS transport unit group passed together
(3/3). The older cutoff comparator now runs six cases, including direct valid
zero at both rates. The four rejection/rearm quaternion-only cutoff cases and
scope check then passed (2/2). All matched current state/covariance/event errors
were zero. These checks also validate generation, source origin and angular
readiness at identical source cutoffs.

Bringup's two failures are **unchanged baseline lint**: flake8 has 3,086 findings
and pep257 has 37. Their exact finding multisets match the baseline. The full
verification command keeps its nonzero aggregate exit; no lint or new failure
was suppressed.

## Installed repeated-flight matrix

Each process uses the installed raw MCT and base relays, one selected integrated
planner, the real schema-2 packer and the actual C++ mailbox decoder. No context
publisher or live command publisher is present. All registration and plant truth
are synthetic. Ten A/B rounds mix genuine rejection, gap-based recovery and
held-to-launch recovery, with source/frame/order faults retained in raw records.
The 750 ms first-worker delay forces an A solve to finish after B starts.

A post-run raw-ledger audit proves **140 A acquisitions and under-table
rejections**, **140 B acquisitions with decoded commands**, and fresh B origins
and spin measurement sources across all initial attempts, including the failed
coverage case. Both delayed cases observe retired-generation work discarded.
Candidate/retained histories and one-running/one-pending work stay bounded.
The failed case has no resource snapshot because its coverage assertion fired
before that snapshot; it is not assigned an invented memory result.

| Hz | Plane policy | Spin | First-worker delay ms | Covered / eligible | Decoder p95 ms | Initial result |
| --- | --- | --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+'''

The frozen valid-publication source-age ceiling and decoder p95 ceiling are
30 ms; coverage is at least 95%. Eligibility uses independently generated source
opportunities with >100 ms elapsed and >130 ms lead. Full source intervals,
exposures, faults, all commands, decoder receipts and denominators are retained.
Failures were not removed from denominators or recast as positive tests.

The new failed timing case recorded a 20.79 ms source interval followed by a
catch-up burst; nine of its twelve missing command epochs were also missing at
the typed-observation recorder. The older failed case recorded a 22.91 ms source
interval and an observed expired input age of 42.53 ms. This demonstrates timing
variability and correct expiry rejection, not proof that every loss was outside
the planner. One exact retry per failed case, using the original full-suite
binaries and scripts, achieved 160/160 (100%). Both first failures remain open
for timing qualification; retries do not establish a hard real-time guarantee.

## Named correction coverage

| ID | Executed regression | Result |
| --- | --- | --- |
'''+ '\n'.join(case_rows)+'''

SP07 additionally passes the real ROS encode/decode path with explicit zero,
invalid flags and nonfinite vectors. Base yaw 0°, ±30° and +50° runs at both
rates establish allowed rotations and nonvacuous turn rejection. The original
net, contact uncertainty, held, 10/12/20 m/s, context races, startup guards,
receiver lifecycle and rollback tests remain present.

## Remaining qualification and evidence

Native Gate3 `--check` exited 2 because the configured
`a3_deploy_onnx_ref_pingpong` package is absent. The instrumented AimRT MuJoCo
install is also absent. Python MuJoCo/ONNX packages are not those runtime assets.
G6 still needs the non-live V2-incoming/legacy-outgoing evaluation adapter and
three-arm actual contact, achieved face-normal/velocity, landing, net clearance,
admission/miss/duplicate and stability/recovery scoring. No force-every-flight
or known-answer target substitution was used.

Real data is available upstream: all nine compressed/uncompressed PPQ004
C3D/CSV/NPZ hashes and lengths matched its manifest at upstream main `8d246424`.
It is 300 Hz table-corner data; parts 1+2 train and part 3 holds out 27 arcs,
24 causally scoreable arcs and only three qualified spin/contact holdouts.
Those are available inputs, not a continuation-planner accuracy result.
Relative capture times do not certify cross-host clock mapping or surveyed
pelvis/table/tool geometry. No newer coefficients, optional runner schemas 4/5,
physical model qualification or operator promotion was silently adopted.

The machine-readable companion records all pins, thresholds, case names,
initial/retry outcomes, file hashes, environment and explicit false qualification
flags. Raw evidence is under `/workspace/.cloud-setup/reacquisition-spin/`:
`baseline-e9bf015/`, `qualification-verified/`, `development/`, the two timing
retry directories, baseline probes and failed exploratory runs. The interrupted
`qualification-final/` run contains a test-constructor compile error fixed before
the clean full run; it is retained, not counted as a passing run.

Reproduce the full ladder inside Ubuntu 24.04 / ROS Jazzy with Eigen/GTest,
NumPy/SciPy and CPU ONNX Runtime:

```bash
bash hope_ws/src/hope_planner_cpp/scripts/flight_prediction_validation/verify_integrated.sh \
  /new/absolute/evidence-directory
```

`HOPE_POLICY_PYTHONPATH` may name an external ONNX Runtime dependency directory.
Every gate preserves its log and exit code. No existing evidence directory is
overwritten. The environment here used GCC 13.3, CMake 3.28.3, Python 3.12.3,
NumPy 1.26.4, SciPy 1.11.4, ONNX Runtime 1.31.0 and isolated localhost ROS domain
193 (specialized tests use their declared isolated domains).
'''
(D/'integrated_planner_reacquisition_spin_qualification.md').write_text(text)
(D/'integrated_planner_reacquisition_draft_pr.md').write_text('''# Recover rejected flights and qualify causal spin in integrated V2

A rejected flight permanently latched automatic acquisition, repeated angular
qualification discarded the history needed for quaternion-only spin, and the
integrated base consumer decoded the producer's WXYZ quaternion in the wrong
order. This continuation introduces evidence-fenced rearm with fresh ownership,
bounded causal candidate spin, truthful readiness diagnostics, correct rotated
base admission and preservation of explicit valid zero through ROS decoding.
Legacy behavior, physics coefficients, policy artifacts and wire schemas remain
pinned; output stays shadow-only.

Validation: 18 native and 18 ASan/UBSan groups, 26 historical review cases,
RA01–RA08/SP01–SP09/BP01–BP05, 701 exact legacy comparisons, 144 explicitly
DOP853 outgoing cases, two policy artifacts and real producer/decoder checks.
All 140 initial A/B pairs recover with decoded B commands. Full ROS initially
passed 96/100 planner groups; two instrumentation issues were corrected and
passed targeted retests. Two 300 Hz coverage cases failed at 92.5% and 91.25%;
each exact retry passed 100%, but timing qualification remains open. Bringup's
two lint failures exactly match baseline. G6/G7 remain NOT_RUN.

See `integrated_planner_reacquisition_spin_qualification.md` and its JSON for
source pins, denominators, failed runs and remaining work. This is a local draft,
not an upstream submission or deployment request. PR64 is closed and unmerged.
''')
p=D/'integrated_planner_review_remaining_qualification.md';s=p.read_text();s=s.replace('# Remaining integrated qualification\n','# Remaining integrated qualification\n\nThis is the historical PR64 correction roadmap. The later continuation results,\nincluding recovered consecutive flights and the still-open timing gate, are in\n[integrated_planner_reacquisition_spin_qualification.md](integrated_planner_reacquisition_spin_qualification.md).\nIts G0–G7 numbering is separate from the historical V3 gates below.\n',1);p.write_text(s)
p=D/'integrated_planner_input_contract.md';s=p.read_text();s+='\nExplicit producer `omega_valid=true` with a finite zero vector represents measured\nzero through the ROS decoder as well as the native engine. `omega_valid=false`\nand nonfinite vectors remain unavailable; no zero is inferred from missing data.\n';p.write_text(s)
# Every changed path already belongs to the full upstream inventory. Record
# the additional transport and diagnostic verification ownership explicitly.
p=D/'integrated_planner_reacquisition_scope_manifest.json';m=json.loads(p.read_text());changed=set(subprocess.check_output(['git','-C',str(R),'diff','--name-only','e9bf015'],text=True).splitlines())
for item in m['files']:
 if item['path'] in changed:
  item['continuation_change']={'owner':'integrated planner continuation','base':d['base_sha'],'why_needed':'Reacquisition, source-causal spin, explicit measured zero, base contract, diagnostic verification or truthful qualification evidence.','tests':['reacquisition_spin','base_pose_contract','test_flight_transport_v2','reacquisition_chain_*','review_source_cutoff_parity','flight_v2_scope']}
p.write_text(json.dumps(m,indent=2)+'\n')
print('Wrote qualification Markdown, JSON, draft PR and scope/migration references')
